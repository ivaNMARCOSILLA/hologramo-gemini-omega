import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const text=ts.transpileModule(readFileSync('lib/ciudad-attachments.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {validateAttachments:validate,attachmentContent,readBoundedBody}=await import('data:text/javascript;base64,'+Buffer.from(text).toString('base64'));
test('text attachments preserve Unicode without adding executable instructions',()=>{
 const files=validate([{name:'ideas.md',kind:'text',text:'España 日本語'}]);
 assert.equal(attachmentContent('Resume',files)[2].text,'España 日本語');
 assert.equal(attachmentContent('Hola',[]),'Hola');
});
test('image headers must match their declared type; URLs and SVG are rejected',()=>{
 const png='data:image/png;base64,'+Buffer.from('\x89PNG\r\n\x1a\n','binary').toString('base64');
 assert.equal(validate([{name:'a.png',kind:'image',dataUrl:png}]).length,1);
 for(const dataUrl of ['https://localhost/private','data:image/svg+xml;base64,AAAA','data:image/png;base64,aGVsbG8='])assert.throws(()=>validate([{name:'a',kind:'image',dataUrl}]));
});
test('oversized streaming bodies are stopped even without content-length',async()=>{
 const request=new Request('https://example.com',{method:'POST',body:'x'.repeat(101)});
 await assert.rejects(readBoundedBody(request,100),/too_large/);
 assert.equal(await readBoundedBody(new Request('https://example.com',{method:'POST',body:'España'}),100),'España');
});
test('language catalogue has unique validated identifiers and file extensions',async()=>{
 const compiled=ts.transpileModule(readFileSync('lib/ciudad-code-languages.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
 const {codeLanguages,codeLanguage}=await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'));
 assert.equal(codeLanguages.length,new Set(codeLanguages.map(l=>l.id)).size);
 assert.ok(codeLanguages.length>=80);
 assert.equal(codeLanguage('rust').extension,'rs');assert.equal(codeLanguage('react').extension,'tsx');
 assert.equal(codeLanguage('rust; rm -rf /'),undefined);
});
