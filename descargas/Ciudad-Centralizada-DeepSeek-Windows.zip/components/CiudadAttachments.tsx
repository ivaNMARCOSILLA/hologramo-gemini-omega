'use client';
import {useRef,useState} from 'react';
import {validateAttachments,type Attachment} from '@/lib/ciudad-attachments';
import type {Locale} from '@/lib/ciudad-i18n';
export default function CiudadAttachments({files,onChange,disabled,locale}:{files:Attachment[];onChange:(files:Attachment[])=>void;disabled:boolean;locale:Locale}){
 const ref=useRef<HTMLInputElement>(null);const [error,setError]=useState('');
 const labels={es:['Adjuntar archivos','Hasta 3 archivos: TXT, MD, CSV, JSON y código (10 000 caracteres), o PNG, JPEG y WebP (256 KB). Se envían a DeepSeek al pulsar Enviar. No se guardan en el historial.','No se pudo leer el archivo. Revisa formato, tamaño y cantidad.','Quitar'],en:['Attach files','Up to 3 files: text, Markdown, CSV, JSON and code (10,000 characters), or PNG, JPEG and WebP (256 KB). Sent to DeepSeek when you submit. Not saved in history.','Unable to read file. Check format, size and count.','Remove'],fr:['Joindre des fichiers','3 fichiers maximum : texte, Markdown, CSV, JSON et code (10 000 caractères), ou PNG, JPEG et WebP (256 Ko). Envoyés à DeepSeek avec votre message, sans conservation dans l’historique.','Fichier illisible. Vérifiez le format, la taille et le nombre.','Retirer'],pt:['Anexar ficheiros','Até 3 ficheiros: texto, Markdown, CSV, JSON e código (10 000 caracteres), ou PNG, JPEG e WebP (256 KB). Enviados a DeepSeek com a mensagem. Não são guardados no histórico.','Não foi possível ler o ficheiro. Verifique formato, tamanho e quantidade.','Remover']}[locale];
 async function read(selected:File[]){
  try{
   const next=[...files];
   if(next.length+selected.length>3)throw Error();
   for(const file of selected){
    if(file.size>256000)throw Error();
    const name=file.name.slice(0,120);
    if(/\.(png|jpe?g|webp)$/i.test(name)){
     const dataUrl=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=reject;reader.readAsDataURL(file);});
     next.push({name,kind:'image',dataUrl});
    }else{
     if(!/\.(txt|md|csv|json|log|ts|tsx|js|jsx|py|html|css|sql|xml|yaml|yml)$/i.test(name)||file.size>40000)throw Error();
     next.push({name,kind:'text',text:await file.text()});
    }
   }
   onChange(validateAttachments(next));setError('');
  }catch{setError(labels[2]);}
  finally{if(ref.current)ref.current.value='';}
 }
 return <div className="cc-attachments"><label>{labels[0]}<input ref={ref} type="file" multiple disabled={disabled} accept=".txt,.md,.csv,.json,.log,.ts,.tsx,.js,.jsx,.py,.html,.css,.sql,.xml,.yaml,.yml,.png,.jpg,.jpeg,.webp" onChange={e=>void read(Array.from(e.target.files||[]))}/></label><small>{labels[1]}</small><ul>{files.map((file,i)=><li key={i}>{file.name} <button type="button" disabled={disabled} onClick={()=>onChange(files.filter((_,n)=>n!==i))} aria-label={`${labels[3]} ${file.name}`}>{labels[3]}</button></li>)}</ul>{error&&<p role="alert">{error}</p>}</div>;
}
