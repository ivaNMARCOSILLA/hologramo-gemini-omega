'use client';

import { useEffect, useState } from 'react';
import { createBrowserClient } from '@supabase/ssr';
import { KeyRound, LogOut, ShieldCheck } from 'lucide-react';
import { registerPersonalAccount } from '@/lib/ciudad-registration';
import { accountMessages } from '@/lib/ciudad-account-i18n';
import { announce, type Locale } from '@/lib/ciudad-i18n';
import OmegaAdminBadge from '@/components/OmegaAdminBadge';

// Registro personal sin promociones de rol ni contratación.
// Conserva Supabase Auth, segundo factor y los módulos administrativos existentes.
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
let cached: ReturnType<typeof createBrowserClient> | null = null;
function client() {
  if (!url || !key) return null;
  if (!cached) cached = createBrowserClient(url, key);
  return cached;
}

type Account = { id: string; email: string | null };
export default function OmegaV09Account({locale='es'}:{locale?:Locale}) {
  const text=accountMessages[locale];
  const [account, setAccount] = useState<Account | null>(null);
  const [ready, setReady] = useState(!url || !key);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [registering, setRegistering] = useState(false);
  const [confirmation, setConfirmation] = useState('');
  const [privacyRead, setPrivacyRead] = useState(false);
  const [hasFactor, setHasFactor] = useState(false);
  const [mfaLevel, setMfaLevel] = useState('aal1');
  const [factorId, setFactorId] = useState('');
  const [mfaCode, setMfaCode] = useState('');
  const [totpSecret, setTotpSecret] = useState('');

  useEffect(() => {
    const sb = client();
    if (!sb) return;
    let active = true;
    const refresh = async () => {
      const { data: userData } = await sb.auth.getUser();
      if (!active) return;
      const user = userData.user;
      setAccount(user ? { id: user.id, email: user.email || null } : null);
      const { data: aal } = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
      const { data: factors } = await sb.auth.mfa.listFactors();
      if (active) {
        setMfaLevel(aal?.currentLevel || 'aal1');
        const verified = factors?.totp.find((f: {status: string; id: string}) => f.status === 'verified');
        setHasFactor(Boolean(verified));
        setFactorId(verified?.id || '');
      }
      setReady(true);
    };
    void refresh().catch(() => { if (active) setReady(true); });
    const { data: authListener } = sb.auth.onAuthStateChange(() => {
      // No hay actualizaciones de pago. La cuenta sigue requiriendo autenticación real.
      setTimeout(() => { if (active) void refresh().catch(() => undefined); }, 0);
    });
    return () => { active = false; authListener.subscription.unsubscribe(); };
  }, []);

  async function login() {
    const sb = client();
    if (!sb) return;
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setMessage(text.invalidEmail);
      return;
    }
    setBusy(true);
    try {
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) throw error;
      setPassword('');
      setMessage(text.loggedIn);
    } catch (e) { setMessage(e instanceof Error ? e.message : text.failed); }
    finally { setBusy(false); }
  }

  async function register() {
    const sb = client(); if (!sb) return;
    setBusy(true);
    try {
      const result = await registerPersonalAccount(sb.auth, {email,password,confirmation,privacyRead}, window.location.origin);
      setPassword(''); setConfirmation(''); setMessage(text[result]);
    } catch (error) {
      const code = error instanceof Error ? error.message : 'failed';
      setMessage(code === 'invalidEmail' || code === 'mismatch' || code === 'consent' || code === 'failed' ? text[code] : code);
    }
    finally { setBusy(false); }
  }

  async function disableMfa() {
    const sb = client(); if (!sb) return;
    if (mfaLevel !== 'aal2') { setMessage(text.verifyFirst); return; }
    setBusy(true);
    try {
      const {data, error} = await sb.auth.mfa.listFactors();
      if (error) throw error;
      for (const factor of data.totp) {
        const result = await sb.auth.mfa.unenroll({factorId: factor.id});
        if (result.error) throw result.error;
      }
      setHasFactor(false); setFactorId(''); setTotpSecret(''); setMfaCode('');
      const refreshed = await sb.auth.refreshSession();
      if (refreshed.error) throw refreshed.error;
      const assurance = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
      setMfaLevel(assurance.data?.currentLevel || 'aal1');
      setMessage(text.disabled);
    } catch (error) { setMessage(error instanceof Error ? error.message : text.failed); }
    finally { setBusy(false); }
  }

  async function logout() {
    const sb = client(); if (!sb) return;
    setBusy(true);
    try {
      const {error}=await sb.auth.signOut();if(error)throw error;
      setHasFactor(false);setFactorId('');setAccount(null);setMfaLevel('aal1');setTotpSecret('');setMfaCode('');setMessage(text.signedOut);
    }catch(error){setMessage(error instanceof Error?error.message:text.failed);}
    finally{setBusy(false);}
  }

  async function resetPassword() {
    const sb = client(); if (!sb || !/^\S+@\S+\.\S+$/.test(email)) {
      setMessage(text.invalidEmail); return;
    }
    setBusy(true);
    try {
      const { error } = await sb.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/callback?next=/cuenta`,
      });
      if (error) throw error;
      setMessage(text.sent);
    } catch (e) { setMessage(e instanceof Error ? e.message : text.failed); }
    finally { setBusy(false); }
  }

  async function enrollMfa() {
    const sb = client(); if (!sb) return;
    setBusy(true);
    try {
      const { data: factors, error: listError } = await sb.auth.mfa.listFactors();
      if (listError) throw listError;
      const verified = factors.totp.find((f: { status: string; id: string }) => f.status === 'verified');
      if (verified) { setFactorId(verified.id); setMessage(text.mfaSetup); return; }
      const { data, error } = await sb.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'Ciudad Centralizada personal' });
      if (error || !data?.totp) throw error || new Error(text.mfaError);
      setFactorId(data.id); setTotpSecret(data.totp.secret);
      setMessage(text.mfaSetup);
    } catch (e) { setMessage(e instanceof Error ? e.message : text.mfaError); }
    finally { setBusy(false); }
  }

  async function verifyMfa() {
    const sb = client(); if (!sb) return;
    if (!/^\d{6}$/.test(mfaCode)) { setMessage(text.mfaError); return; }
    setBusy(true);
    try {
      let id = factorId;
      if (!id) {
        const { data, error } = await sb.auth.mfa.listFactors();
        if (error) throw error;
        id = data.totp.find((f: { status: string; id: string }) => f.status === 'verified')?.id || '';
      }
      if (!id) throw new Error(text.mfaSetup);
      const { data, error } = await sb.auth.mfa.challenge({ factorId: id });
      if (error || !data) throw error || new Error(text.mfaError);
      const check = await sb.auth.mfa.verify({ factorId: id, challengeId: data.id, code: mfaCode });
      if (check.error) throw check.error;
      setHasFactor(true); setMfaLevel('aal2'); setMfaCode(''); setTotpSecret('');
      setMessage(text.mfaReady);
    } catch (e) { setMessage(e instanceof Error ? e.message : text.mfaError); }
    finally { setBusy(false); }
  }

  useEffect(()=>{if(message)announce(message);},[message]);

  return <section aria-busy={busy} className="ou-v09-account ou-section" aria-label="Cuenta personal Ciudad Centralizada">
    <OmegaAdminBadge locale={locale}/>
    <div className="ou-v09-account-title">
      <ShieldCheck size={25} />
      <div><h2>{text.title}</h2><p>{text.intro}</p></div>
    </div>
    {!url || !key ? <p role="status">{text.unavailable}</p>
    : !ready ? <p>{text.checking}</p>
    : account ? <div className="ou-v09-account-status">
        <strong>{text.session}: {account.email || 'Cuenta Ciudad Centralizada'}</strong>
        <p>{text.optional}</p>
        <p>{text.protection}: {mfaLevel === 'aal2' ? text.verified : text.pending}</p>
        <div className="ou-v09-account-actions">
          <button type="button" disabled={busy} onClick={() => void logout()}><LogOut size={15} /> {text.logout}</button>
          {hasFactor && mfaLevel === 'aal2' && <button type="button" disabled={busy} onClick={() => void disableMfa()}>{text.disable}</button>}
          {mfaLevel !== 'aal2' && <button type="button" disabled={busy} onClick={() => void enrollMfa()}>{text.setup}</button>}
        </div>
        {mfaLevel !== 'aal2' && (hasFactor || factorId) && <div className="ou-v09-mfa">
          {totpSecret && <p>{text.temporary}: <code>{totpSecret}</code>. {text.private}</p>}
          <label>{text.totp} <input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={mfaCode} onChange={e => setMfaCode(e.target.value.replace(/\D/g, '').slice(0,6))} /></label>
          <button type="button" disabled={busy || mfaCode.length !== 6} onClick={() => void verifyMfa()}>{text.verify}</button>
        </div>}
      </div>
    : <form className="ou-v09-signin" onSubmit={e => { e.preventDefault(); void (registering ? register() : login()); }}>
        <label htmlFor="omega-personal-email">{text.email}
          <input id="omega-personal-email" type="email" autoComplete="username" required value={email} onChange={e => setEmail(e.target.value)} />
        </label>
        <label htmlFor="omega-personal-password">{text.password}
          <input id="omega-personal-password" type="password" autoComplete={registering ? "new-password" : "current-password"} minLength={registering ? 12 : undefined} required value={password} onChange={e => setPassword(e.target.value)} />
        </label>
        {registering && <>
          <p>{text.passwordHint}</p>
          <label htmlFor="ciudad-confirm">{text.confirm}<input id="ciudad-confirm" type="password" autoComplete="new-password" required minLength={12} value={confirmation} onChange={e => setConfirmation(e.target.value)}/></label>
          <label><input type="checkbox" checked={privacyRead} required onChange={e => setPrivacyRead(e.target.checked)}/>{text.consent}</label>
          <a href="/privacidad" target="_blank" rel="noopener noreferrer">{text.privacy}</a>
        </>}
        <div className="ou-v09-account-actions">
          <button type="submit" disabled={busy}><KeyRound size={16} /> {registering ? text.register : text.login}</button>
          <button type="button" disabled={busy} onClick={() => {setRegistering(!registering);setPassword('');setConfirmation('');setMessage('');}}>{registering ? text.back : text.register}</button>
          {!registering && <button type="button" disabled={busy} onClick={() => void resetPassword()}>{text.reset}</button>}
        </div>
      </form>}
    {message && <p className="ou-v09-account-message" role="status">{message}</p>}
    <p>{text.foot}</p>
  </section>;
}
