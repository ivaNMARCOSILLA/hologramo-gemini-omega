/** Server-only DeepSeek integration. Never imported by client components. */
export type AiMessage = { role: 'system' | 'user' | 'assistant'; content: string };
export class DeepSeekError extends Error {
  constructor(public code: string, public status = 503) { super(code); }
}
export function deepseekModel(): string {
  return process.env.DEEPSEEK_MODEL?.trim() || 'deepseek-flash';
}
function key(): string {
  const value = process.env.DEEPSEEK_API_KEY?.trim();
  if (!value) throw new DeepSeekError('deepseek_not_configured');
  return value;
}
function providerError(status: number): DeepSeekError {
  if (status === 401 || status === 403) return new DeepSeekError('deepseek_key_rejected');
  if (status === 402) return new DeepSeekError('deepseek_insufficient_balance');
  if (status === 429) return new DeepSeekError('deepseek_rate_limited', 429);
  return new DeepSeekError('deepseek_provider_error', 502);
}
export async function deepseekChat(messages: AiMessage[], options: { json?: boolean; signal?: AbortSignal; maxTokens?: number } = {}) {
  const apiKey = key(), model = deepseekModel();
  try {
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST', redirect: 'error', cache: 'no-store',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages, stream: false, thinking: { type: 'disabled' }, temperature: 0.2,
        max_tokens: Math.min(options.maxTokens || 900, 2000),
        ...(options.json ? { response_format: { type: 'json_object' } } : {}),
      }),
      signal: AbortSignal.any([...(options.signal ? [options.signal] : []), AbortSignal.timeout(50_000)]),
    });
    if (!response.ok) throw providerError(response.status);
    const body: unknown = await response.json();
    const content = body && typeof body === 'object'
      ? (body as { choices?: { message?: { content?: unknown } }[] }).choices?.[0]?.message?.content : null;
    if (typeof content !== 'string' || !content.trim()) throw new DeepSeekError('deepseek_empty_reply', 502);
    return { text: content.trim(), model, provider: 'DeepSeek', tokensPerSecond: null };
  } catch (error) {
    if (error instanceof DeepSeekError) throw error;
    if (options.signal?.aborted) throw new DeepSeekError('request_cancelled', 499);
    throw new DeepSeekError(error instanceof Error && error.name === 'TimeoutError' ? 'deepseek_timeout' : 'deepseek_unreachable', 502);
  }
}
/** Read-only credential/model check; does not request a billed completion. */
export async function deepseekStatus() {
  const model = deepseekModel();
  try {
    const response = await fetch('https://api.deepseek.com/models', {
      headers: { Authorization: `Bearer ${key()}` }, redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(8000),
    });
    if (!response.ok) throw providerError(response.status);
    const data = await response.json() as { data?: { id: string }[] };
    const ready = Array.isArray(data.data) && data.data.some(item => item.id === model);
    return { ready, model, provider: 'DeepSeek', compute: 'API', error: ready ? null : 'deepseek_model_unavailable' };
  } catch (error) {
    return { ready: false, model, provider: 'DeepSeek', compute: 'API', error: error instanceof DeepSeekError ? error.code : 'deepseek_unreachable' };
  }
}
