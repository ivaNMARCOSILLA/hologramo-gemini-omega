#!/usr/bin/env bash
set -euo pipefail
# CPU only. Docker must be available. The port never listens on a public interface.
ciudad_model_dir="${CIUDAD_MODEL_DIR:-/workspace/ciudad-models}"
mkdir -p "$ciudad_model_dir"
if docker container inspect ciudad-llama >/dev/null 2>&1; then
  docker start ciudad-llama >/dev/null
else
  docker run -d --name ciudad-llama --cpus=4 --memory=8g \
    -p 127.0.0.1:11434:11434 -v "$ciudad_model_dir:/root/.ollama" \
    -e OLLAMA_NUM_PARALLEL=1 -e OLLAMA_MAX_LOADED_MODELS=1 \
    -e OLLAMA_CONTEXT_LENGTH=4096 -e OLLAMA_NO_CLOUD=1 -e CUDA_VISIBLE_DEVICES=-1 \
    ollama/ollama@sha256:2b8eecdb85aa6ea67c381c8ecffec04b2658496cf2821a8f88b0485bdff198e8 >/dev/null
fi
# Trust the platform's managed egress CA when present. Never disable TLS verification.
ciudad_proxy_ca=/usr/local/share/ca-certificates/environment-proxy-ca.crt
if [ -f "$ciudad_proxy_ca" ]; then
  ciudad_host_hash=$(sha256sum "$ciudad_proxy_ca" | cut -d ' ' -f 1)
  ciudad_container_hash=$(docker exec ciudad-llama sh -c 'sha256sum /usr/local/share/ca-certificates/environment-proxy-ca.crt 2>/dev/null' | cut -d ' ' -f 1 || true)
  if [ "$ciudad_host_hash" != "$ciudad_container_hash" ]; then
    docker cp "$ciudad_proxy_ca" ciudad-llama:/usr/local/share/ca-certificates/environment-proxy-ca.crt
    docker exec ciudad-llama update-ca-certificates
    docker restart ciudad-llama >/dev/null
  fi
fi
for attempt in {1..20}; do
  if curl --max-time 2 -fsS http://127.0.0.1:11434/api/version >/dev/null; then exit 0; fi
  sleep 1
done
printf '%s\n' 'Ollama did not become ready. Inspect the container startup log.' >&2
exit 1
