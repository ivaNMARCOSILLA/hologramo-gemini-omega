﻿. (Join-Path $PSScriptRoot 'windows-common.ps1')
try {
    Set-Location -LiteralPath $script:CiudadRoot
    Initialize-CiudadNode
    if (-not (Test-Path -LiteralPath 'node_modules') -or -not (Test-Path -LiteralPath '.next/BUILD_ID')) {
        throw 'Primero ejecuta INSTALAR-CIUDAD.cmd para instalar y compilar la web.'
    }
    Write-Host 'Arrancando la web local. Abre la direccion Local que aparezca debajo.'
    Write-Host 'Manten esta ventana abierta. Ctrl+C detiene el servidor.'
    Invoke-CiudadNative 'npm.cmd' @('run', 'start', '--', '--hostname', '127.0.0.1')
    exit 0
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
