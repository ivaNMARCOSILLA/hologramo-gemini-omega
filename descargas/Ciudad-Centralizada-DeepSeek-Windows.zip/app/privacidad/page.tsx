import CiudadLegal from '@/components/CiudadLegal';
export default function Privacy(){return <CiudadLegal kind="privacy"/>;}
