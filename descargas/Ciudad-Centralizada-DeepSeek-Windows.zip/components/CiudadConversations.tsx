'use client';
import {useEffect,useRef,useState} from 'react';
import {createBrowserClient} from '@supabase/ssr';
import type {ChatMessage} from '@/app/page';
import type {Locale} from '@/lib/ciudad-i18n';
type Conversation={id:string;title:string;messages:ChatMessage[];updated:number};
function read(key:string):Conversation[]{
 const raw=localStorage.getItem(key);if(!raw||raw.length>2000000)return [];
 const value:unknown=JSON.parse(raw);if(!Array.isArray(value))return [];
 return value.slice(0,20).filter((item):item is Conversation=>Boolean(item&&typeof item.id==='string'&&typeof item.title==='string'&&item.title.length<=100&&typeof item.updated==='number'&&Array.isArray(item.messages)&&item.messages.length<=30&&item.messages.every((m:ChatMessage)=>m&&['user','assistant'].includes(m.role)&&typeof m.content==='string'&&m.content.length<=12000)));
}
export default function CiudadConversations({chat,onLoad,busy,locale}:{chat:ChatMessage[];onLoad:(messages:ChatMessage[])=>void;busy:boolean;locale:Locale}){
 const [key,setKey]=useState<string|null>(null);const [items,setItems]=useState<Conversation[]>([]);const [active,setActive]=useState<string|null>(null);const [notice,setNotice]=useState('');
 const load=useRef(onLoad);useEffect(()=>{load.current=onLoad;},[onLoad]);
 const text={es:['Conversaciones','Nueva conversación','Guardar conversación','Inicia sesión para guardar tus conversaciones en este navegador.','Guardado local: hasta 20 conversaciones. No se sincronizan entre dispositivos. Guarda los cambios antes de cambiar de conversación.','Eliminar','No se pudo guardar. El navegador puede tener el almacenamiento lleno o bloqueado.','Conversación guardada.'],en:['Conversations','New conversation','Save conversation','Sign in to save conversations in this browser.','Local storage: up to 20 conversations. No device sync. Save changes before switching conversations.','Delete','Unable to save. Browser storage may be full or blocked.','Conversation saved.'],fr:['Conversations','Nouvelle conversation','Enregistrer la conversation','Connectez-vous pour enregistrer vos conversations dans ce navigateur.','Stockage local : 20 conversations maximum, sans synchronisation. Enregistrez avant de changer de conversation.','Supprimer','Enregistrement impossible. Le stockage est peut-être plein ou bloqué.','Conversation enregistrée.'],pt:['Conversas','Nova conversa','Guardar conversa','Inicie sessão para guardar conversas neste navegador.','Armazenamento local: até 20 conversas, sem sincronização. Guarde antes de mudar de conversa.','Eliminar','Não foi possível guardar. O armazenamento pode estar cheio ou bloqueado.','Conversa guardada.']}[locale];
 useEffect(()=>{const reset=()=>setActive(null);window.addEventListener('ciudad:new-chat',reset);return()=>window.removeEventListener('ciudad:new-chat',reset);},[]);
 useEffect(()=>{
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL,token=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  if(!url||!token)return;
  const sb=createBrowserClient(url,token);let alive=true;let generation=0;let identity:string|null=null;
  async function refresh(){
   const current=++generation;
   const {data,error}=await sb.auth.getUser();if(!alive||current!==generation)return;
   const next=!error&&data.user?`ciudad:conversations:${data.user.id}`:null;
   if(identity&&identity!==next)load.current([]);
   identity=next;setKey(next);setActive(null);
   try{setItems(next?read(next):[]);}catch{setItems([]);}
  }
  void refresh();
  const {data}=sb.auth.onAuthStateChange(event=>{
   if(event==='SIGNED_OUT'||event==='SIGNED_IN'||event==='USER_UPDATED'){
    ++generation;setKey(null);setItems([]);setActive(null);
    if(event==='SIGNED_OUT')load.current([]);
    setTimeout(()=>{if(alive)void refresh();},0);
   }
  });
  return()=>{alive=false;++generation;data.subscription.unsubscribe();};
 },[]);
 function persist(next:Conversation[]){if(!key)return false;try{const encoded=JSON.stringify(next);if(encoded.length>2000000)throw Error();localStorage.setItem(key,encoded);setItems(next);return true;}catch{setNotice(text[6]);return false;}}
 function save(){
  if(!key||!chat.length)return;
  const id=active||crypto.randomUUID();
  const entry={id,title:(chat.find(m=>m.role==='user')?.content||text[0]).slice(0,100),messages:chat.slice(-30),updated:Date.now()};
  const next=[entry,...items.filter(item=>item.id!==id)];
  if(next.length>20){setNotice(text[4]);return;}
  if(persist(next)){setActive(id);setNotice(text[7]);}
 }
 return <section className="cc-history" aria-label={text[0]}><h2>{text[0]}</h2><p>{key?text[4]:text[3]}</p><div className="cc-actions"><button type="button" disabled={busy} onClick={()=>{setActive(null);load.current([]);setNotice('');}}>{text[1]}</button><button type="button" disabled={busy||!key||!chat.length} onClick={save}>{text[2]}</button></div><ul>{items.map(item=><li key={item.id}><button type="button" disabled={busy} aria-pressed={active===item.id} onClick={()=>{setActive(item.id);load.current(item.messages);}}>{item.title}</button><button type="button" disabled={busy} aria-label={`${text[5]} ${item.title}`} onClick={()=>{if(persist(items.filter(x=>x.id!==item.id))&&active===item.id){setActive(null);load.current([]);}}}>{text[5]}</button></li>)}</ul>{notice&&<p role="status">{notice}</p>}</section>;
}
