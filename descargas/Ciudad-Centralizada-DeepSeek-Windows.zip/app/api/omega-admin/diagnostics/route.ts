import { deepseekStatus } from "@/lib/ciudad-deepseek";
import { omegaAdminGate } from "@/lib/omega-admin-access";

/**
 * OMEGA diagnóstico v1. SOLO LECTURA y solo admin (verificado en servidor).
 * De las variables de entorno solo informa si existen; nunca devuelve sus valores.
 */
const headers = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };
const VARS = [
  "NEXT_PUBLIC_SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY", "DEEPSEEK_API_KEY",
  "SUPABASE_SERVICE_ROLE_KEY", "DEEPSEEK_MODEL", "STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET",
  "NEXT_PUBLIC_OMEGA_BILLING_ENABLED",
];



export async function GET(request: Request): Promise<Response> {
  try {
    const access = await omegaAdminGate(request, false);
    if (access.state !== "admin") return Response.json({ error: access.state }, { status: access.status, headers });

    const env: Record<string, boolean> = Object.fromEntries(VARS.map((v) => [v, !!process.env[v]]));
    const runtime = {
      vercel: !!process.env.VERCEL,
      region: process.env.VERCEL_REGION ?? null,
      node: process.version,
      env: process.env.NODE_ENV ?? "desconocido",
    };
    const deepseek = await deepseekStatus();
    return Response.json({ mfa: access.mfa, runtime, env, deepseek, model: deepseek.model }, { status: 200, headers });
  } catch {
    return Response.json({ error: "diagnostics_failed" }, { status: 503, headers });
  }
}