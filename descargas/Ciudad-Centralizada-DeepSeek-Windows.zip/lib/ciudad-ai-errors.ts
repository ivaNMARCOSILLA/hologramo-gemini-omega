import { translate, type Locale } from './ciudad-i18n';
const errors = {
 es: {
  deepseek_not_configured:'Falta DEEPSEEK_API_KEY en este despliegue. Añádela en el servidor y vuelve a desplegar.',
  deepseek_key_rejected:'DeepSeek ha rechazado la clave del servidor. Revisa su validez y los permisos.',
  deepseek_insufficient_balance:'La cuenta de DeepSeek no tiene saldo suficiente. No se ha enviado ninguna acción.',
  deepseek_rate_limited:'DeepSeek está limitando las consultas. Espera un momento antes de volver a intentarlo.',
  deepseek_model_unavailable:'El modelo configurado no está disponible en esta cuenta de DeepSeek.',
  deepseek_timeout:'DeepSeek ha tardado demasiado en responder. La solicitud no ha ejecutado ninguna acción.',
  invalid_control_reply:'La IA devolvió una respuesta que no se puede validar. No se ha ejecutado ninguna orden.',
 },
 en: {
  deepseek_not_configured:'DEEPSEEK_API_KEY is missing in this deployment. Add it on the server and redeploy.',
  deepseek_key_rejected:'DeepSeek rejected the server API key. Check its validity and permissions.',
  deepseek_insufficient_balance:'The DeepSeek account has insufficient balance. No action was dispatched.',
  deepseek_rate_limited:'DeepSeek is rate limiting requests. Please wait before trying again.',
  deepseek_model_unavailable:'The configured model is not available in this DeepSeek account.',
  deepseek_timeout:'DeepSeek took too long to respond. This request did not execute any action.',
  invalid_control_reply:'The AI response could not be validated. No command was executed.',
 },
 fr: {
  deepseek_not_configured:'DEEPSEEK_API_KEY manque dans ce déploiement. Ajoutez-la au serveur puis redéployez.',
  deepseek_key_rejected:'DeepSeek a refusé la clé du serveur. Vérifiez sa validité et ses permissions.',
  deepseek_insufficient_balance:'Le solde du compte DeepSeek est insuffisant. Aucune action envoyée.',
  deepseek_rate_limited:'DeepSeek limite les demandes. Patientez avant de réessayer.',
  deepseek_model_unavailable:'Le modèle configuré est indisponible sur ce compte DeepSeek.',
  deepseek_timeout:'DeepSeek a mis trop de temps à répondre. Aucune action exécutée.',
  invalid_control_reply:'La réponse de l’IA est invalide. Aucune commande exécutée.',
 },
 pt: {
  deepseek_not_configured:'Falta DEEPSEEK_API_KEY neste ambiente. Adicione-a no servidor e volte a publicar.',
  deepseek_key_rejected:'DeepSeek rejeitou a chave do servidor. Verifique a validade e as permissões.',
  deepseek_insufficient_balance:'A conta DeepSeek não tem saldo suficiente. Nenhuma ação foi enviada.',
  deepseek_rate_limited:'DeepSeek está a limitar os pedidos. Aguarde antes de tentar novamente.',
  deepseek_model_unavailable:'O modelo configurado não está disponível nesta conta DeepSeek.',
  deepseek_timeout:'DeepSeek demorou demasiado a responder. Nenhuma ação foi executada.',
  invalid_control_reply:'A resposta da IA não pôde ser validada. Nenhum comando foi executado.',
 },
};
export function aiErrorMessage(code: string, locale: Locale): string {
 if (code==='auth') return translate(locale,'signIn');
 return Object.hasOwn(errors[locale],code) ? errors[locale][code as keyof typeof errors.es] : translate(locale,'serverMissing');
}
