import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const source=ts.transpileModule(readFileSync(new URL('../lib/ciudad-registration.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {registerPersonalAccount:register}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const valid={email:' person@example.com ',password:'a-long-password!',confirmation:'a-long-password!',privacyRead:true};
test('registration strips role injection and uses only canonical callback and credentials',async()=>{
 let received;
 const result=await register({signUp:async args=>{received=args;return {data:{session:null},error:null};}},{...valid,role:'admin',data:{role:'admin'}},'https://hologramo.es');
 assert.equal(result,'registered');
 assert.deepEqual(received,{email:'person@example.com',password:valid.password,options:{emailRedirectTo:'https://hologramo.es/auth/callback'}});
});
test('invalid registration never calls Auth',async()=>{
 const auth={signUp:()=>assert.fail('Auth must not be called')};
 for (const input of [{...valid,email:'bad'},{...valid,password:'short'},{...valid,confirmation:'different'},{...valid,privacyRead:false}]) await assert.rejects(register(auth,input,'https://hologramo.es'));
 await assert.rejects(register(auth,valid,'http://untrusted.example'));
});
test('registration distinguishes immediate session from pending email confirmation',async()=>{
 assert.equal(await register({signUp:async()=>({data:{session:{access_token:'mock'}},error:null})},valid,'http://localhost:3000'),'created');
});
test('Auth failures are surfaced and never reported as a created account',async()=>{
 await assert.rejects(register({signUp:async()=>({data:{session:null},error:new Error('signup disabled')})},valid,'https://hologramo.es'),/signup disabled/);
});
