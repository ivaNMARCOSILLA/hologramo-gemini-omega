// Only static application targets reach an OS process. No user text is executed.
const windows={calculator:['calc.exe',[]],notepad:['notepad.exe',[]],explorer:['explorer.exe',[]],paint:['mspaint.exe',[]],snipping:['SnippingTool.exe',[]],edge:['cmd.exe',['/d','/c','start','','msedge']],chrome:['cmd.exe',['/d','/c','start','','chrome']],settings:['cmd.exe',['/d','/c','start','','ms-settings:']],word:['cmd.exe',['/d','/c','start','','winword']],excel:['cmd.exe',['/d','/c','start','','excel']],powerpoint:['cmd.exe',['/d','/c','start','','powerpnt']],vscode:['cmd.exe',['/d','/c','start','','code']]};
const mac={calculator:'Calculator',notepad:'TextEdit',explorer:'Finder',edge:'Microsoft Edge',chrome:'Google Chrome',settings:'System Settings',word:'Microsoft Word',excel:'Microsoft Excel',powerpoint:'Microsoft PowerPoint',vscode:'Visual Studio Code'};
export function applicationTarget(platform,app){
 if(typeof app!=='string')return null;
 if(platform==='win32'&&Object.hasOwn(windows,app)){const[command,args]=windows[app];return{command,args:[...args]};}
 if(platform==='darwin'&&Object.hasOwn(mac,app))return{command:'/usr/bin/open',args:['-a',mac[app]]};
 return null;
}
export function validJob(value){return !!value&&typeof value==='object'&&typeof value.id==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(value.id)&&typeof value.app==='string';}
export function agentOrigin(raw){const url=new URL(raw);if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw new Error('CIUDAD_SITE_URL must be a plain HTTPS origin');return url.origin;}
