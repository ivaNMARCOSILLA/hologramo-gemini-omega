import type { SupabaseClient } from '@supabase/supabase-js';

type Registration = { email: string; password: string; confirmation: string; privacyRead: boolean };
export async function registerPersonalAccount(auth: Pick<SupabaseClient['auth'], 'signUp'>, input: Registration, origin: string) {
  const email = input.email.trim();
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('invalidEmail');
  if (input.password.length < 12 || input.password !== input.confirmation) throw new Error('mismatch');
  if (!input.privacyRead) throw new Error('consent');
  const site = new URL(origin);
  if (site.protocol !== 'https:' && !(site.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(site.hostname))) throw new Error('failed');
  // Explicit fields only: client-supplied roles and metadata never reach Auth.
  const {data, error} = await auth.signUp({email, password: input.password,
    options: {emailRedirectTo: `${site.origin}/auth/callback`}});
  if (error) throw error;
  return data.session ? 'created' : 'registered';
}
