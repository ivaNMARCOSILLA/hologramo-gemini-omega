﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:CiudadRoot = Split-Path -Parent $PSScriptRoot

function Invoke-CiudadNative {
    param([string]$Program, [string[]]$CommandArguments)
    & $Program @CommandArguments
    if ($LASTEXITCODE -ne 0) { throw "El comando fallo (codigo $LASTEXITCODE): $Program" }
}

function Update-CiudadPath {
    $ciudadMachinePath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $ciudadUserPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    if ($ciudadMachinePath) { $env:Path = $ciudadMachinePath + ';' + $ciudadUserPath }
}

function Initialize-CiudadNode {
    param([switch]$NoInstall)
    $ciudadNode = Get-Command node.exe -ErrorAction SilentlyContinue
    $ciudadMajor = 0
    if ($ciudadNode) {
        $ciudadVersion = & $ciudadNode.Source --version
        if ($LASTEXITCODE -eq 0 -and $ciudadVersion -match '^v(\d+)\.') { $ciudadMajor = [int]$Matches[1] }
    }
    if ($ciudadMajor -lt 24) {
        if ($NoInstall) { throw 'Se necesita Node.js 24 o superior. La comprobacion no instalara ni cambiara programas.' }
        $ciudadWinget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $ciudadWinget) {
            throw 'Instala Node.js 24 LTS desde https://nodejs.org/ y vuelve a abrir este instalador. Windows no dispone de winget.'
        }
        Write-Host 'Instalando Node.js LTS mediante winget. Windows puede pedir permiso de instalacion.'
        Invoke-CiudadNative $ciudadWinget.Source @('install', '--id', 'OpenJS.NodeJS.LTS', '--exact', '--source', 'winget', '--accept-package-agreements', '--accept-source-agreements')
        Update-CiudadPath
        $ciudadNode = Get-Command node.exe -ErrorAction SilentlyContinue
        if (-not $ciudadNode) { throw 'Node se ha instalado, pero no aparece en PATH. Cierra esta ventana y ejecuta el instalador de nuevo.' }
        $ciudadVersion = & $ciudadNode.Source --version
        if ($LASTEXITCODE -ne 0 -or $ciudadVersion -notmatch '^v(\d+)\.' -or [int]$Matches[1] -lt 24) {
            throw 'Se necesita Node.js 24 o superior. Reabre la consola despues de instalar Node.'
        }
    }
    if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'No se encuentra npm.cmd. Reinstala Node.js LTS con npm incluido.' }
    Write-Host ('Node: ' + (& node.exe --version))
    Write-Host ('npm:  ' + (& npm.cmd --version))
}

function Show-CiudadBindings {
    $ciudadProbe = 'process.stdout.write(JSON.stringify({deepseek:Boolean(process.env.DEEPSEEK_API_KEY),supabase:Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL&&process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY)}))'
    $ciudadProbeArguments = @()
    if (Test-Path -LiteralPath '.env.local') { $ciudadProbeArguments += '--env-file=.env.local' }
    $ciudadProbeArguments += @('-e', $ciudadProbe)
    $ciudadBindingsJson = & node.exe @ciudadProbeArguments
    if ($LASTEXITCODE -ne 0) { throw 'No se pudo comprobar .env.local. No se ha cambiado el archivo.' }
    $ciudadBindings = $ciudadBindingsJson | ConvertFrom-Json
    if ($ciudadBindings.deepseek) { Write-Host 'DEEPSEEK_API_KEY: presente (valor oculto).' }
    else { Write-Warning 'Falta DEEPSEEK_API_KEY para probar la IA localmente. El editor sigue disponible; no se crea una clave falsa.' }
    if ($ciudadBindings.supabase) { Write-Host 'Configuracion publica de Supabase: presente.' }
    else { Write-Warning 'Falta configuracion de Supabase para iniciar sesion. La IA mantiene su requisito de administrador y MFA.' }
}

function Invoke-CiudadVercel {
    param([string[]]$CommandArguments)
    $ciudadCliArguments = @('--yes', 'vercel@65.1.0') + $CommandArguments + @('--no-color')
    Invoke-CiudadNative 'npx.cmd' $ciudadCliArguments
}

function Get-CiudadVercelResult {
    param([string[]]$CommandArguments)
    $ciudadCliArguments = @('--yes', 'vercel@65.1.0') + $CommandArguments + @('--no-color')
    # The CLI writes status lines to stderr. Capture them without treating its banner as a failure.
    $ErrorActionPreference = 'Continue'
    $ciudadLines = @(& npx.cmd @ciudadCliArguments 2>&1 | ForEach-Object { $_.ToString() })
    $ciudadExit = $LASTEXITCODE
    return [pscustomobject]@{ ExitCode = $ciudadExit; Output = ($ciudadLines -join "`n") }
}
