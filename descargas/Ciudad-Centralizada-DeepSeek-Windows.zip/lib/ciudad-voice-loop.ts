/** One recognition loop shared by voice commands and dictated text. */
export function createVoiceLoop(start:()=>void, stop:()=>void, schedule:(run:()=>void)=>()=>void) {
 let enabled=false, busy=false, speaking=false, listening=false, disposed=false;
 let cancel:(()=>void)|null=null;
 const clear=()=>{cancel?.();cancel=null;};
 const ready=()=>enabled&&!busy&&!speaking&&!listening&&!disposed;
 const resume=()=>{clear();if(!ready())return;cancel=schedule(()=>{cancel=null;if(ready())start();});};
 return {
  enable(){enabled=true;clear();if(ready())start();},
  disable(){enabled=false;clear();listening=false;stop();},
  processing(value:boolean){busy=value;if(value){clear();stop();}else resume();},
  speech(value:boolean){speaking=value;if(value){clear();stop();}else resume();},
  started(){listening=true;clear();},
  ended(){listening=false;resume();},
  dispose(){disposed=true;enabled=false;clear();stop();},
 };
}
export type CiudadVoiceLoop=ReturnType<typeof createVoiceLoop>;
