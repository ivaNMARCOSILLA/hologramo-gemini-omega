@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0scripts\publicar-vercel.ps1" %*
set "CIUDAD_EXIT=%ERRORLEVEL%"
if not "%CIUDAD_EXIT%"=="0" echo La operacion no se ha completado. Revisa el mensaje anterior.
pause
exit /b %CIUDAD_EXIT%
