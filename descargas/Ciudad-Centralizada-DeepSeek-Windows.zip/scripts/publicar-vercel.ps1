﻿param([string]$Scope = '')
. (Join-Path $PSScriptRoot 'windows-common.ps1')
try {
    Set-Location -LiteralPath $script:CiudadRoot
    Initialize-CiudadNode
    $env:VERCEL_TELEMETRY_DISABLED = '1'
    $ciudadScopeArguments = @()
    if ($Scope) { $ciudadScopeArguments = @('--scope', $Scope) }
    $ciudadProjectName = 'holograma-gemini'
    Write-Host 'Comprobando la sesion de Vercel...'
    $ciudadIdentity = Get-CiudadVercelResult @('whoami')
    if ($ciudadIdentity.ExitCode -ne 0) {
        Write-Host 'Inicia sesion en Vercel mediante el navegador cuando la CLI lo indique.'
        Invoke-CiudadVercel @('login')
    }
    Write-Host ('Buscando el proyecto EXISTENTE: ' + $ciudadProjectName)
    $ciudadInspectArguments = @('project', 'inspect', $ciudadProjectName, '--json') + $ciudadScopeArguments
    $ciudadInspection = Get-CiudadVercelResult $ciudadInspectArguments
    if ($ciudadInspection.ExitCode -ne 0) {
        throw 'El proyecto no es accesible con esta cuenta/equipo. No se creara otro. Usa PUBLICAR-VERCEL.cmd -Scope nombre-del-equipo si pertenece a otro equipo.'
    }
    $ciudadJsonMatch = [regex]::Match($ciudadInspection.Output, '(?s)\{.*\}')
    if (-not $ciudadJsonMatch.Success) { throw 'Vercel no devolvio metadatos del proyecto validos. No se ha publicado nada.' }
    $ciudadProject = $ciudadJsonMatch.Value | ConvertFrom-Json
    if ($ciudadProject.PSObject.Properties['project']) { $ciudadProject = $ciudadProject.project }
    if ($ciudadProject.name -ne $ciudadProjectName -or -not $ciudadProject.id) {
        throw 'El proyecto recibido no coincide con holograma-gemini. Publicacion cancelada.'
    }
    if ($ciudadProject.PSObject.Properties['rootDirectory'] -and $ciudadProject.rootDirectory -and $ciudadProject.rootDirectory -ne '.') {
        throw 'Este ZIP contiene la aplicacion en su raiz. Revisa Root Directory del proyecto en Vercel antes de publicar; no se cambiara automaticamente.'
    }
    if (Test-Path -LiteralPath '.vercel/project.json') {
        $ciudadExistingLink = Get-Content -LiteralPath '.vercel/project.json' -Raw | ConvertFrom-Json
        if ($ciudadExistingLink.projectId -ne $ciudadProject.id) {
            throw 'La carpeta ya esta vinculada a otro proyecto. No se modificara esa vinculacion. Usa una carpeta nueva extraida del ZIP.'
        }
    }
    # Default env-list output contains names and targets; --json is intentionally NOT used because it can reveal values.
    $ciudadEnvArguments = @('env', 'ls', '--environment', 'production', '--project', $ciudadProject.id) + $ciudadScopeArguments
    $ciudadRemoteEnvironment = Get-CiudadVercelResult $ciudadEnvArguments
    if ($ciudadRemoteEnvironment.ExitCode -ne 0) { throw 'No se pueden comprobar los nombres de variables de Production. No se ha publicado nada.' }
    foreach ($ciudadRequiredName in @('DEEPSEEK_API_KEY', 'NEXT_PUBLIC_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY')) {
        if ($ciudadRemoteEnvironment.Output -notmatch ('(?<![A-Za-z0-9_])' + [regex]::Escape($ciudadRequiredName) + '(?![A-Za-z0-9_])')) {
            throw ('Falta ' + $ciudadRequiredName + ' en Production del proyecto. Anadela en Vercel y vuelve a ejecutar este archivo. .env.local no se sube.')
        }
        Write-Host ($ciudadRequiredName + ': declarada en Production (valor oculto).')
    }
    Write-Host 'Preparando dependencias, pruebas y compilacion local...'
    Invoke-CiudadNative 'npm.cmd' @('ci', '--no-audit', '--no-fund')
    Invoke-CiudadNative 'npm.cmd' @('exec', '--', 'next', 'typegen')
    Invoke-CiudadNative 'npm.cmd' @('run', 'typecheck')
    Invoke-CiudadNative 'npm.cmd' @('test')
    Invoke-CiudadNative 'npm.cmd' @('run', 'build')
    Write-Host 'Publicando las fuentes en holograma-gemini. Vercel compilara con sus variables de Production.'
    # An explicit verified project ID and NO --create-if-missing prevent accidental project creation.
    $ciudadDeployArguments = @('deploy', '--project', $ciudadProject.id, '--prod', '--yes', '--verify') + $ciudadScopeArguments
    Invoke-CiudadVercel $ciudadDeployArguments
    Write-Host 'Despliegue terminado. Comprueba con tu cuenta y MFA la respuesta real de DeepSeek.'
    Write-Host 'La comprobacion HTTP de Vercel no prueba por si sola la IA ni el agente de Windows/macOS.'
    exit 0
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
