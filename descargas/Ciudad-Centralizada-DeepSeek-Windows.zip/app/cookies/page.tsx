import CiudadLegal from '@/components/CiudadLegal';
export default function Cookies(){return <CiudadLegal kind="cookies"/>;}
