﻿param([switch]$Comprobar)
. (Join-Path $PSScriptRoot 'windows-common.ps1')
try {
    Set-Location -LiteralPath $script:CiudadRoot
    Write-Host 'CIUDAD CENTRALIZADA - Preparacion para Windows'
    Initialize-CiudadNode -NoInstall:$Comprobar
    Show-CiudadBindings
    if ($Comprobar) { Write-Host 'Comprobacion terminada. No se han instalado dependencias.'; exit 0 }
    Write-Host '[1/4] Instalando las versiones de package-lock.json...'
    Invoke-CiudadNative 'npm.cmd' @('ci', '--no-audit', '--no-fund')
    Write-Host '[2/4] Generando tipos de Next.js y comprobando TypeScript...'
    Invoke-CiudadNative 'npm.cmd' @('exec', '--', 'next', 'typegen')
    Invoke-CiudadNative 'npm.cmd' @('run', 'typecheck')
    Write-Host '[3/4] Ejecutando pruebas...'
    Invoke-CiudadNative 'npm.cmd' @('test')
    Write-Host '[4/4] Compilando la web...'
    Invoke-CiudadNative 'npm.cmd' @('run', 'build')
    Write-Host ''
    Write-Host 'Instalacion terminada. No se han modificado .env.local, tu cuenta ni el agente de escritorio.'
    Write-Host 'Abre VER-WEB.cmd para probar la web en este ordenador.'
    Write-Host 'Abre PUBLICAR-VERCEL.cmd para publicar en el proyecto existente hologramo-gemini.'
    exit 0
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
