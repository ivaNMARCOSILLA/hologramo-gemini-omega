import test from 'node:test';import assert from 'node:assert/strict';
import {applicationTarget,validJob,agentOrigin} from '../scripts/ciudad-agent-policy.mjs';
test('desktop targets are platform-specific and never interpolate user code',()=>{
 assert.deepEqual(applicationTarget('win32','calculator'),{command:'calc.exe',args:[]});
 assert.deepEqual(applicationTarget('darwin','notepad'),{command:'/usr/bin/open',args:['-a','TextEdit']});
 for(const input of ['calculator; rm -rf /','__proto__','constructor','powershell','calc.exe',{},null])assert.equal(applicationTarget('win32',input),null);
 assert.equal(applicationTarget('linux','calculator'),null);assert.equal(applicationTarget('darwin','paint'),null);
});
test('agent only accepts HTTPS origins without embedded credentials or paths',()=>{
 assert.equal(agentOrigin('https://hologramo.es'),'https://hologramo.es');
 for(const input of ['http://hologramo.es','https://user:pass@host.test','https://host.test/path','https://host.test/?key=value'])assert.throws(()=>agentOrigin(input));
});
test('jobs need a complete UUID and application identifier',()=>{
 assert.equal(validJob({id:'01234567-0123-4567-89ab-0123456789ab',app:'calculator'}),true);
 for(const input of [null,{id:'../file',app:'calculator'},{id:'01234567-0123-4567-89ab-0123456789ab',app:[]}])assert.equal(validJob(input),false);
});
