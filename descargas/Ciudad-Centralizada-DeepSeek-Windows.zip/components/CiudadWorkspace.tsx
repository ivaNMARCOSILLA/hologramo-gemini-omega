'use client';

import Link from 'next/link';
import {codeLanguageGroups,codeLanguage} from '@/lib/ciudad-code-languages';
import CiudadAttachments from './CiudadAttachments';
import CiudadConversations from './CiudadConversations';
import type {Attachment} from '@/lib/ciudad-attachments';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowRight, BookOpen, ChevronRight, CircleHelp, Code2, Copy, Cpu, Feather, Globe2, Home, LayoutGrid, Leaf, Mic, Monitor, NotebookPen, Plus, Settings2, ShieldCheck, Square, Trash2, Volume2 } from 'lucide-react';
import { aiErrorMessage } from '@/lib/ciudad-ai-errors';
import { announce, locales, translate, type Locale, type MessageKey } from '@/lib/ciudad-i18n';
import { adminFetch } from '@/lib/omega-admin-fetch';
import { sendRemoteWindowsOrder } from '@/lib/omega-voz-dictadora';
import type { CentralInstruction } from '@/lib/omega-central';
import type { ChatMessage, CiudadPrefs } from '@/app/page';
import CiudadDevices from './CiudadDevices';
import OmegaV09Account from './OmegaV09Account';

type Section='home'|'tools'|'code'|'ideas'|'devices'|'guide'|'settings'|'account';
type Props={locale:Locale;onLocale:(value:Locale)=>void;prefs:CiudadPrefs;onPrefs:(value:CiudadPrefs)=>void;
 chat:ChatMessage[];onClearChat:()=>void;onLoadChat:(messages:ChatMessage[])=>void;onAsk:(text:string,files?:Attachment[])=>void;busy:boolean;listening:boolean;speaking:boolean;micSupported:boolean;
 transcript:string;status:string;onMic:()=>void;onStop:()=>void};
const nav:{id:Section;icon:typeof Home}[]=[{id:'home',icon:Home},{id:'tools',icon:NotebookPen},{id:'code',icon:Code2},{id:'ideas',icon:Leaf},{id:'devices',icon:Monitor},{id:'guide',icon:BookOpen},{id:'settings',icon:Settings2},{id:'account',icon:ShieldCheck}];
const sectionMap:Record<string,Section>={inicio:'home',herramientas:'tools',codigo:'code',conocimiento:'ideas',acciones:'devices',avisos:'guide',ajustes:'settings',cuenta:'account','ia-avanzada':'home'};
function download(text:string,name:string,type='text/plain;charset=utf-8'){
 const url=URL.createObjectURL(new Blob([text],{type}));const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
export default function CiudadWorkspace(props:Props){
 const {locale,onLocale,prefs,onPrefs,chat,onClearChat,onAsk,busy,listening,speaking,micSupported,transcript,status,onMic,onStop}=props;
 const t=useCallback((key:MessageKey)=>translate(locale,key),[locale]);
 const [sidebarOpen,setSidebarOpen]=useState(false);
 const [section,setSection]=useState<Section>('home');const [deviceRequest,setDeviceRequest]=useState<string|null>(null);const [input,setInput]=useState('');const [editor,setEditor]=useState('');
 const [files,setFiles]=useState<Attachment[]>([]);
 const [ideas,setIdeas]=useState<string[]>([]);const [idea,setIdea]=useState('');const [codePrompt,setCodePrompt]=useState('');
 const [language,setLanguage]=useState('python');const [code,setCode]=useState('');const [codeBusy,setCodeBusy]=useState(false);
 const [consent,setConsent]=useState<boolean|null>(null);const [loaded,setLoaded]=useState(false);
 const [voices,setVoices]=useState<SpeechSynthesisVoice[]>([]);
 const [runtime,setRuntime]=useState('');const [runtimeBusy,setRuntimeBusy]=useState(false);
 useEffect(()=>{const pane=document.querySelector('.cc-thread');if(pane)pane.scrollTop=pane.scrollHeight;},[chat,busy]);
 const heading=useRef<HTMLHeadingElement>(null);const previousSection=useRef(section);const lastAnnouncement=useRef(0);
 const codeAbort=useRef<AbortController|null>(null);const remoteBusy=useRef(false);
 useEffect(()=>{
  const restore=setTimeout(()=>{
  if(window.location.hash === '#cuenta')setSection('account');
  try{
   const choice=JSON.parse(localStorage.getItem('ciudad:consent')||'null');
   if(choice?.version===1){setConsent(choice.preferences===true);if(choice.preferences){
    const saved=JSON.parse(localStorage.getItem('ciudad:preferences')||'{}');
    if(saved.locale in locales)onLocale(saved.locale);
    if(saved.prefs&&typeof saved.prefs==='object')onPrefs({voice:saved.prefs.voice===true,large:saved.prefs.large===true,contrast:saved.prefs.contrast===true,motion:saved.prefs.motion!==false,rate:typeof saved.prefs.rate==='number'?Math.min(1.4,Math.max(.7,saved.prefs.rate)):1,voiceURI:typeof saved.prefs.voiceURI==='string'?saved.prefs.voiceURI:'',volume:typeof saved.prefs.volume==='number'?Math.max(0,Math.min(1,saved.prefs.volume)):1});
   }}
   const notes:unknown=JSON.parse(localStorage.getItem('ciudad:ideas')||'[]');
   if(Array.isArray(notes))setIdeas(notes.filter((note):note is string=>typeof note==='string').slice(0,30));
  }catch{/* Storage can be unavailable in private browsing. */}
  setLoaded(true);
  },0);
  const mark=()=>{lastAnnouncement.current=Date.now();};window.addEventListener('ciudad:feedback',mark);
  return()=>{clearTimeout(restore);window.removeEventListener('ciudad:feedback',mark);codeAbort.current?.abort();};
 // Preferences are restored once; edits stay in the current session unless consent permits persistence.
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[]);
 useEffect(()=>{if(loaded&&consent)try{localStorage.setItem('ciudad:preferences',JSON.stringify({locale,prefs}));}catch{}},[loaded,consent,locale,prefs]);
 useEffect(()=>{document.documentElement.dataset.contrast=String(prefs.contrast);document.documentElement.dataset.large=String(prefs.large);document.documentElement.dataset.motion=String(prefs.motion);},[prefs]);
 useEffect(()=>{if(previousSection.current!==section){heading.current?.focus();previousSection.current=section;}},[section]);
 useEffect(()=>{if(!('speechSynthesis' in window))return;const update=()=>setVoices(window.speechSynthesis.getVoices());const timer=setTimeout(update,0);window.speechSynthesis.addEventListener('voiceschanged',update);return()=>{clearTimeout(timer);window.speechSynthesis.removeEventListener('voiceschanged',update);};},[]);
 const go=useCallback((target:Section)=>{setSidebarOpen(false);setSection(target);announce(`${t('selected')}: ${t(target)}`);},[t]);
 const saveIdea=useCallback((text:string)=>{
  if(!text.trim())return;
  const next=[text.trim().slice(0,1500),...ideas].slice(0,30);setIdeas(next);
  try{localStorage.setItem('ciudad:ideas',JSON.stringify(next));announce(t('saved'));}catch{announce(t('failed'));}
 },[ideas,t]);
 const copy=useCallback(async(text:string)=>{try{await navigator.clipboard.writeText(text);announce(t('copied'));}catch{announce(t('failed'));}},[t]);
 const generate=useCallback(async(text=codePrompt,lang=language)=>{
  if(!text.trim()||codeAbort.current)return;
  const abort=new AbortController();codeAbort.current=abort;setCodeBusy(true);announce(t('thinking'),false);
  try{
   const response=await adminFetch('/api/omega-admin/code',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:text,language:lang}),signal:abort.signal});
   if(!response||response.status===401)throw new Error('auth');
   if(response.status===403){const denied=await response.json();throw new Error(denied.error==='mfa_required'?'mfa_required':'not_admin');}
   const body=await response.json();if(!response.ok||typeof body.code!=='string')throw new Error(body.error||'server');
   if(!abort.signal.aborted){setCode(body.code);announce(t('done'));}
  }catch(error){if(!abort.signal.aborted)announce(aiErrorMessage(error instanceof Error?error.message:'unknown',locale));}
  finally{codeAbort.current=null;setCodeBusy(false);}
 },[codePrompt,language,t,locale]);
 const checkRuntime=async()=>{
  setRuntimeBusy(true);try{const response=await adminFetch('/api/omega-admin/ai');if(!response||response.status===401){setRuntime(t('signIn'));announce(t('signIn'));return;} if(response.status===403){const denied=await response.json();const message=aiErrorMessage(denied.error==='mfa_required'?'mfa_required':'not_admin',locale);setRuntime(message);announce(message);return;}
   const body=await response.json();const message=body.ready?`${body.model} · DeepSeek API · ${t('connected')}`:aiErrorMessage(body.error||'unknown',locale);setRuntime(message);announce(message);
  }catch{setRuntime(t('serverMissing'));announce(t('serverMissing'));}finally{setRuntimeBusy(false);}
 };
 const sendWindows=useCallback(async(text:string)=>{
  if(remoteBusy.current){announce(t('preparing'));return;}
  remoteBusy.current=true;setSection('devices');
  try{await sendRemoteWindowsOrder(text,announce);}finally{remoteBusy.current=false;}
 },[t]);
 useEffect(()=>{
  const receive=(event:Event)=>{
   const action=(event as CustomEvent<CentralInstruction>).detail;if(!action)return;
   switch(action.kind){
    case 'device':setDeviceRequest(action.text);setSection('devices');return;
    case 'navigate':go(sectionMap[action.section]||'home');return;
    case 'navigate_step':{const index=nav.findIndex(n=>n.id===section);go(nav[(index+action.step+nav.length)%nav.length].id);return;}
    case 'idea_save':saveIdea(action.text);setSection('ideas');return;
    case 'ideas_show':go('ideas');return;
    case 'editor_append':setEditor(old=>old+(old?'\n':'')+action.text);go('tools');return;
    case 'editor_clear':setEditor('');announce(t('done'));return;
    case 'editor_copy':void copy(editor);return;
    case 'editor_paste':void navigator.clipboard.readText().then(text=>{setEditor(old=>old+text);announce(t('done'));},()=>announce(t('permission')));return;
    case 'editor_dictate':go('tools');window.dispatchEvent(new CustomEvent('ciudad:dictate',{detail:'tools'}));return;
    case 'code_prepare':setCodePrompt(action.text);if(action.language)setLanguage(action.language);go('code');return;
    case 'code_language':setLanguage(action.language==='batch'?'powershell':action.language);go('code');return;
    case 'code_clear':setCode('');setCodePrompt('');announce(t('done'));return;
    case 'code_copy':void copy(code);return;
    case 'code_download':case 'signature_export':announce(t('selected')+': '+t('download'));go('code');return;
    case 'code_dictate':go('code');window.dispatchEvent(new CustomEvent('ciudad:dictate',{detail:'code'}));return;
    case 'windows_open':void sendWindows(action.text);return;
    case 'windows_diagnostic':case 'agent_status':go('devices');announce(t('devicesHelp'));return;
    case 'agent_disarm':go('devices');announce(t('windowsHelp'));return;
    case 'accessibility':onPrefs({...prefs,...(action.feature==='large'?{large:action.value}:action.feature==='reduced-motion'?{motion:action.value}:{})});announce(t('done'));return;
    case 'theme':onPrefs({...prefs,contrast:action.theme==='contraste'});announce(t('done'));return;
    case 'help':go('guide');return;
    default:announce(t('guideTitle'));go('guide');
   }
  };
  window.addEventListener('ciudad:command',receive);return()=>window.removeEventListener('ciudad:command',receive);
 },[section,go,saveIdea,editor,code,copy,prefs,onPrefs,sendWindows,t]);
 useEffect(()=>{if(section!=='devices'||!deviceRequest)return;const timer=setTimeout(()=>{window.dispatchEvent(new CustomEvent('ciudad:device',{detail:deviceRequest}));setDeviceRequest(null);},50);return()=>clearTimeout(timer);},[section,deviceRequest]);
 useEffect(()=>{const receive=(event:Event)=>{const {target,text}=(event as CustomEvent<{target:string;text:string}>).detail;if(target==='tools')setEditor(old=>old+(old?'\n':'')+text);else if(target==='code')setCodePrompt(text);announce(t('done'));};window.addEventListener('ciudad:dictation-result',receive);return()=>window.removeEventListener('ciudad:dictation-result',receive);},[t]);
 const dictate=(target:'tools'|'code')=>window.dispatchEvent(new CustomEvent('ciudad:dictate',{detail:target}));
 useEffect(()=>{const clear=()=>{setFiles([]);codeAbort.current?.abort();setCode('');setEditor('');setCodePrompt('');};window.addEventListener('ciudad:signed-out',clear);return()=>window.removeEventListener('ciudad:signed-out',clear);},[]);
 const chooseConsent=(preferences:boolean)=>{setConsent(preferences);try{localStorage.setItem('ciudad:consent',JSON.stringify({version:1,preferences}));if(!preferences)localStorage.removeItem('ciudad:preferences');}catch{}announce(t('done'));};


 return <div className={`cc-app ${section==='home'?'cc-chat-mode':''} ${sidebarOpen?'cc-sidebar-open':''}`} onKeyDown={event=>{if(event.key==='Escape')setSidebarOpen(false);}} onClickCapture={event=>{
   const target=(event.target as HTMLElement).closest<HTMLButtonElement>('button');if(!target||target.disabled)return;
   const before=lastAnnouncement.current;const label=target.getAttribute('aria-label')||target.textContent?.trim();
   queueMicrotask(()=>{if(before===lastAnnouncement.current&&label)announce(`${t('selected')}: ${label.slice(0,120)}`,false);});
 }}>
  <a className="cc-skip" href="#main-content">{t('skip')}</a>
  <aside id="cc-main-sidebar" className="cc-sidebar">
   <button className="cc-sidebar-close" type="button" aria-label={t('back')} onClick={()=>setSidebarOpen(false)}>×</button>
   <Link className="cc-brand" href="/" aria-label="Ciudad Centralizada"><span className="cc-brand-mark"><LayoutGrid size={24}/></span><span>ciudad<br/><b>centralizada.</b></span></Link>
   <div className="cc-nav-caption">{t('today')}</div>
   <nav aria-label={t('navigation')}>{nav.map(({id,icon:Icon})=><button key={id} type="button" aria-label={t(id)} aria-current={section===id?'page':undefined} className={section===id?'active':''} onClick={()=>go(id)}><Icon size={19} aria-hidden="true"/><span>{t(id)}</span>{section===id&&<span className="cc-nav-dot"/>}</button>)}</nav>
   {section==='home'&&<CiudadConversations chat={chat} onLoad={messages=>{setFiles([]);setInput('');setSidebarOpen(false);props.onLoadChat(messages);}} busy={busy} locale={locale}/>}
   <div className="cc-sidebar-note"><Leaf size={22}/><p>{t('introText')}</p><button type="button" onClick={()=>go('guide')}>{t('explore')} <ArrowRight size={15}/></button></div>
   <div className="cc-author"><span>{t('signature')}</span><strong>Ivan el notas</strong><small>{t('signatureNote')}</small></div>
  </aside>
  <div className="cc-body">
   <header className="cc-topbar"><button className="cc-sidebar-toggle" type="button" aria-label={t('navigation')} aria-expanded={sidebarOpen} aria-controls="cc-main-sidebar" onClick={()=>setSidebarOpen(!sidebarOpen)}><LayoutGrid size={19}/></button><span><span className="cc-status-dot"/>{t('ready')}</span><div><label className="cc-language"><Globe2 size={16}/><span className="sr-only">{t('language')}</span><select aria-label={t('language')} value={locale} onChange={e=>{onLocale(e.target.value as Locale);announce(locales[e.target.value as Locale]);}}>{Object.entries(locales).map(([id,label])=><option key={id} value={id}>{label}</option>)}</select></label><button type="button" className="cc-round" aria-label={t('settings')} onClick={()=>go('settings')}><Settings2 size={19}/></button><button type="button" className="cc-avatar" aria-label={t('account')} onClick={()=>go('account')}>CC</button></div></header>
   <main id="main-content" tabIndex={-1}>
    <div className={`cc-page-heading ${section==='home'?'sr-only':''}`}><div><p className="cc-eyebrow">{t('eyebrow')}</p><h1 tabIndex={-1} ref={heading}>{section==='home'?t('welcome'):t(section)}</h1></div><span className="cc-page-index" aria-hidden="true">0{nav.findIndex(n=>n.id===section)+1} / 08</span></div>
    {section==='home'&&<section className={`cc-chat-screen ${chat.length?'has-messages':'is-empty'}`} aria-label={t('assistant')}>
      <div className="cc-chat-header"><span>Ciudad Centralizada <small>· DeepSeek</small></span><button type="button" onClick={()=>{onClearChat();setFiles([]);setInput('');window.dispatchEvent(new Event('ciudad:new-chat'));}} disabled={!chat.length&&!busy} aria-label={t('clear')}><Plus size={17}/><span>{({es:'Nuevo chat',en:'New chat',fr:'Nouvelle discussion',pt:'Nova conversa'})[locale]}</span></button></div>
      <div className="cc-thread" role="log" aria-live="polite" aria-relevant="additions" aria-busy={busy}>
       {chat.length?chat.map((message,index)=><article key={index} className={`cc-message ${message.role}`}><span>{message.role==='user'?t('input'):'Ciudad Centralizada'}</span><p>{message.content}</p>{message.role==='assistant'&&<button className="cc-message-copy" type="button" aria-label={t('copy')} onClick={()=>void copy(message.content)}><Copy size={14}/></button>}</article>):<div className="cc-chat-welcome"><span className="cc-chat-emblem"><Feather size={30}/></span><h2>{({es:'¿Por dónde empezamos?',en:'Where shall we start?',fr:'Par où commencer ?',pt:'Por onde começamos?'})[locale]}</h2><p>{({es:'Tus ideas, una conversación a la vez.',en:'Your ideas, one conversation at a time.',fr:'Vos idées, une conversation à la fois.',pt:'As suas ideias, uma conversa de cada vez.'})[locale]}</p><div className="cc-prompt-suggestions">{({es:['Resume un documento','Ayúdame a escribir','Crea un proyecto de código'],en:['Summarise a document','Help me write','Create a code project'],fr:['Résumer un document','Aidez-moi à écrire','Créer un projet de code'],pt:['Resuma um documento','Ajude-me a escrever','Crie um projeto de código']})[locale].map((prompt,index)=><button type="button" key={prompt} onClick={()=>{setInput(prompt);document.getElementById('cc-question')?.focus();}}>{index===0?<BookOpen size={17}/>:index===1?<NotebookPen size={17}/>:<Code2 size={17}/>}<span>{prompt}</span><ArrowRight size={14}/></button>)}</div></div>}
       {busy&&<p className="cc-thread-thinking" role="status"><span className="cc-status-dot cc-pulse"/>{t('thinking')}…</p>}
      </div>
      <div className="cc-composer-dock">
       {transcript&&<p className="cc-transcript">{t('listening')}: {transcript}</p>}
       <form className="cc-chat-composer" onSubmit={event=>{event.preventDefault();if(input.trim()&&!busy){onAsk(input,files);setInput('');setFiles([]);}}}>
        <label htmlFor="cc-question" className="sr-only">{t('ask')}</label><textarea id="cc-question" rows={2} maxLength={2500} value={input} onChange={event=>setInput(event.target.value)} onKeyDown={event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.nativeEvent.isComposing){event.preventDefault();event.currentTarget.form?.requestSubmit();}}} placeholder={t('placeholder')}/>
        <div className="cc-composer-controls"><details className="cc-attachment-options"><summary aria-label={({es:'Adjuntar archivos',en:'Attach files',fr:'Joindre des fichiers',pt:'Anexar ficheiros'})[locale]}><Plus size={20}/>{files.length>0&&<span>{files.length}</span>}</summary><CiudadAttachments files={files} onChange={setFiles} disabled={busy} locale={locale}/></details><span className="cc-composer-hint">{({es:'Mayús + Intro para otra línea',en:'Shift + Enter for a new line',fr:'Maj + Entrée pour une ligne',pt:'Shift + Enter para nova linha'})[locale]}</span><button className="cc-round" type="button" disabled={!micSupported} aria-label={listening?t('stop'):t('talk')} aria-pressed={listening} onClick={onMic}><Mic size={19}/></button>{busy?<button className="cc-chat-send" type="button" aria-label={t('stop')} onClick={onStop}><Square size={18}/></button>:<button className="cc-chat-send" type="submit" disabled={!input.trim()} aria-label={t('send')}><ArrowRight size={20}/></button>}</div>
       </form>
       <p className="cc-chat-disclaimer">{({es:'La IA puede cometer errores. Revisa la información importante.',en:'AI can make mistakes. Check important information.',fr:'L’IA peut se tromper. Vérifiez les informations importantes.',pt:'A IA pode cometer erros. Verifique as informações importantes.'})[locale]}</p>
      </div>
    </section>}
    {section==='tools'&&<section className="cc-panel"><h2>{t('editorTitle')}</h2><p>{t('editorHelp')}</p><label htmlFor="cc-editor">{t('tools')}</label><textarea id="cc-editor" rows={14} maxLength={100000} value={editor} onChange={e=>setEditor(e.target.value)}/><div className="cc-actions"><button type="button" disabled={!micSupported||busy} onClick={()=>dictate('tools')}><Mic size={16}/>{t('talk')}</button><button className="cc-primary" type="button" disabled={!editor.trim()} onClick={()=>saveIdea(editor)}><Plus size={16}/>{t('save')}</button><button type="button" disabled={!editor} onClick={()=>void copy(editor)}><Copy size={16}/>{t('copy')}</button><button type="button" disabled={!editor} onClick={()=>{download(editor,'ciudad-nota.txt');announce(t('done'));}}><ArrowDownToLine size={16}/>{t('download')}</button><button type="button" disabled={!editor} onClick={()=>{setEditor('');announce(t('done'));}}>{t('clear')}</button></div></section>}
    {section==='code'&&<section className="cc-panel"><h2>{t('codeTitle')}</h2><p>{t('codeHelp')}</p><label htmlFor="cc-code-language">{t('codeLanguage')}</label><select id="cc-code-language" value={language} onChange={e=>{setLanguage(e.target.value);announce(e.target.value);}}>{codeLanguageGroups.map(group=><optgroup key={group.id} label={group.labels[locale]}>{group.languages.map(lang=><option key={lang.id} value={lang.id}>{lang.label}</option>)}</optgroup>)}</select><label htmlFor="cc-code-prompt">{t('ask')}</label><textarea id="cc-code-prompt" rows={4} maxLength={4000} value={codePrompt} onChange={e=>setCodePrompt(e.target.value)}/><div className="cc-actions"><button type="button" disabled={!micSupported||codeBusy} onClick={()=>dictate('code')}><Mic size={16}/>{t('talk')}</button><button className="cc-primary" type="button" disabled={codeBusy||!codePrompt.trim()} onClick={()=>void generate()}><Code2 size={16}/>{codeBusy?t('thinking'):t('generate')}</button>{codeBusy&&<button type="button" onClick={()=>{codeAbort.current?.abort();announce(t('cancelled'));}}>{t('stop')}</button>}</div><label htmlFor="cc-code-output">{t('code')}</label><textarea id="cc-code-output" className="cc-code-output" rows={14} value={code} onChange={e=>setCode(e.target.value)} spellCheck={false}/><div className="cc-actions"><button type="button" disabled={!code} onClick={()=>void copy(code)}>{t('copy')}</button><button type="button" disabled={!code} onClick={()=>{download(code,`ciudad.${codeLanguage(language)?.extension||'txt'}`);announce(t('done'));}}>{t('download')}</button></div></section>}
    {section==='ideas'&&<section className="cc-panel"><h2>{t('ideas')}</h2><p>{t('ideasHelp')}</p><label htmlFor="cc-idea">{t('save')}</label><textarea id="cc-idea" rows={3} maxLength={1500} value={idea} onChange={e=>setIdea(e.target.value)}/><button type="button" className="cc-primary" disabled={!idea.trim()} onClick={()=>{saveIdea(idea);setIdea('');}}><Plus size={16}/>{t('save')}</button><div className="cc-notes">{ideas.length?ideas.map((note,index)=><article key={index}><span>0{index+1}</span><p>{note}</p><button type="button" aria-label={`${t('remove')} ${index+1}`} onClick={()=>{const next=ideas.filter((_,i)=>i!==index);setIdeas(next);try{localStorage.setItem('ciudad:ideas',JSON.stringify(next));announce(t('done'));}catch{announce(t('failed'));}}}><Trash2 size={16}/></button></article>):<p>{t('noIdeas')}</p>}</div></section>}
    {section==='devices'&&<CiudadDevices locale={locale}/>}
    {section==='guide'&&<section className="cc-panel"><h2>{t('guideTitle')}</h2><div className="cc-guide-grid">{([1,2,3,4] as const).map(number=><article key={number}><span className="cc-step">0{number}</span><h3>{t(`step${number}`)}</h3><p>{t(`step${number}Text`)}</p></article>)}</div><div className="cc-function-guide">{([['tools','editorHelp'],['code','codeHelp'],['ideas','ideasHelp'],['devices','devicesHelp'],['settings','accessibilityHelp'],['account','signIn']] as [Section,MessageKey][]).map(([target,help])=><details key={target} onToggle={event=>{if(event.currentTarget.open)announce(t(target),false);}}><summary>{t(target)}</summary><p>{t(help)}</p><button type="button" onClick={()=>go(target)}>{t(target)} <ArrowRight size={15}/></button></details>)}</div><div className="cc-notice"><CircleHelp size={24}/><p>{t('devicesHelp')} {t('futureApps')}</p></div></section>}
    {section==='settings'&&<section className="cc-panel"><h2>{t('accessibilityTitle')}</h2><p>{t('accessibilityHelp')}</p><div className="cc-settings">{(['voice','large','contrast','motion'] as const).map(key=><label key={key}><span><strong>{t(key)}</strong>{key==='voice'&&<small>{t('voiceHelp')}</small>}</span><input type="checkbox" checked={prefs[key]} onChange={e=>{onPrefs({...prefs,[key]:e.target.checked});announce(`${t(key)}: ${e.target.checked?'✓':'−'}`);}}/></label>)}<label><span>{t('voiceName')}</span><select aria-label={t('voiceName')} value={prefs.voiceURI} onChange={e=>{onPrefs({...prefs,voiceURI:e.target.value});announce(t('done'));}}><option value="">{t('language')}: {locales[locale]}</option>{voices.map(voice=><option key={voice.voiceURI} value={voice.voiceURI}>{voice.name} · {voice.lang} · {voice.localService?'local':'online'}</option>)}</select></label><label><span>{t('volume')}</span><input aria-label={t('volume')} type="range" min="0" max="1" step="0.1" value={prefs.volume} onChange={e=>onPrefs({...prefs,volume:Number(e.target.value)})}/><output>{Math.round(prefs.volume*100)}%</output></label><label><span>{t('rate')}</span><input aria-label={t('rate')} type="range" min="0.7" max="1.4" step="0.1" value={prefs.rate} onChange={e=>onPrefs({...prefs,rate:Number(e.target.value)})}/><output>{prefs.rate.toFixed(1)}×</output></label></div><div className="cc-model"><Cpu size={25}/><div><h3>{t('modelTitle')}</h3><p>{t('modelHelp')}</p><p>{t('license')}</p><button type="button" disabled={runtimeBusy} onClick={()=>void checkRuntime()}>{t('check')}</button><p role="status">{runtime||t('unknown')}</p></div></div><div className="cc-actions"><a href="/privacidad">{t('privacy')}</a><button type="button" onClick={()=>setConsent(null)}>{t('manage')}</button><button type="button" onClick={()=>{try{['ciudad:preferences','ciudad:ideas'].forEach(key=>localStorage.removeItem(key));}catch{}setIdeas([]);setConsent(false);onPrefs({voice:false,large:false,contrast:false,motion:true,rate:1,voiceURI:'',volume:1});try{localStorage.setItem('ciudad:consent',JSON.stringify({version:1,preferences:false}));}catch{}announce(t('dataCleared'));}}>{t('browserData')}</button></div></section>}
    {section==='account'&&<section className="cc-panel cc-account"><OmegaV09Account locale={locale}/></section>}
    <footer className="cc-footer"><span>© Ciudad Centralizada · <span className="cc-signature">Ivan el notas</span></span><div><a href="/privacidad">{t('privacy')}</a><a href="/cookies">{t('cookies')}</a><button type="button" onClick={()=>go('guide')}>{t('guide')}<ChevronRight size={13}/></button></div></footer>
   </main>
   <div className="cc-feedback" role="status" aria-live="polite" aria-atomic="true"><span className={busy||listening||speaking?'cc-pulse cc-status-dot':'cc-status-dot'}/><div><strong>{busy?t('thinking'):listening?t('listening'):speaking?t('speaking'):t('feedback')}</strong><span>{status||t('ready')}</span></div><button type="button" aria-label={t('stop')} onClick={()=>{codeAbort.current?.abort();onStop();}}><Square size={15}/></button><button type="button" aria-label={t('voice')} aria-pressed={prefs.voice} onClick={()=>{onPrefs({...prefs,voice:!prefs.voice});announce(t('voice'));}}><Volume2 size={17}/></button></div>
  </div>
  {loaded&&consent===null&&<section className="cc-consent" aria-label={t('cookies')}><div><ShieldCheck size={22}/><h2>{t('consentTitle')}</h2></div><p>{t('consentText')}</p><a href="/cookies">{t('cookies')}</a><div className="cc-actions"><button type="button" onClick={()=>chooseConsent(false)}>{t('essential')}</button><button type="button" className="cc-primary" onClick={()=>chooseConsent(true)}>{t('preferences')}</button></div></section>}
 </div>;
}
