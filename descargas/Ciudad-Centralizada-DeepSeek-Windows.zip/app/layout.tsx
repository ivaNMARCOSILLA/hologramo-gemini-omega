import type { Metadata } from 'next';
import './ciudad.css';
export const metadata: Metadata = {
  title: 'Ciudad Centralizada · Tu espacio, a tu ritmo',
  description: 'Un escritorio accesible para escribir, conversar y conectar tus herramientas, con Meta Llama y control sobre tus datos.',
  applicationName: 'Ciudad Centralizada',
};
export default function RootLayout({children}:LayoutProps<'/'>) {
  return <html lang="es"><body>{children}</body></html>;
}
