# Asistente central de Ciudad Centralizada

DeepSeek sustituye a Llama/Ollama como inteligencia activa, mediante su API oficial.
Voz, conversación escrita y código comparten el mismo modelo del servidor.
Configuración, privacidad, voz y despliegue al proyecto Vercel existente
`hologramo-gemini`: ver [README.md](README.md).

Se conservan rutas y tablas `omega` para no romper cuentas ni la cola existente.
