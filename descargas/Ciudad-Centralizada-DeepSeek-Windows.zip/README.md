# Ciudad Centralizada

Un escritorio web cálido y accesible para conversar, escribir, guardar ideas y
preparar código. Interfaz, cuenta, guías y privacidad en español, inglés, francés y
portugués. Las rutas/tablas `omega` se conservan por compatibilidad con el despliegue.

## Paquete Windows listo para instalar

Lee primero [LEEME-PRIMERO.md](LEEME-PRIMERO.md). El ZIP incluye:

- `INSTALAR-CIUDAD.cmd`: comprueba Node/npm, instala dependencias bloqueadas y ejecuta tipos, pruebas y compilación.
- `VER-WEB.cmd`: arranca la web ya compilada para probarla en tu ordenador.
- `PUBLICAR-VERCEL.cmd`: autentica la CLI, verifica el proyecto existente `hologramo-gemini` y los nombres de variables Production, valida el código y publica en su ID comprobado. No crea un proyecto distinto.

Extrae en una carpeta nueva y copia allí tu `.env.local` existente. Los scripts no
sobrescriben ni publican ese archivo. Windows puede pedir permiso para instalar Node
mediante winget. No hace falta instalar Python, Ollama ni herramientas de GPU.

## Desarrollo

Node 24 y npm 11 se han utilizado en este entorno:

```bash
npm ci --cache /workspace/.npm-cache
npm run dev -- --hostname 127.0.0.1
npm test
npm exec -- next typegen
npm run typecheck
npm run build
```

Utiliza el checkout existente; las tareas de nube ya están aisladas, sin worktrees
adicionales. Se usan fuentes del sistema y no se carga una escena 3D por defecto.

## DeepSeek como inteligencia central

Conversación, órdenes por voz/texto y generación de código usan la API oficial:
`https://api.deepseek.com/chat/completions`. No se utiliza OpenRouter ni se requiere
un servidor Ollama en el localhost de Vercel.

Variables **solo del servidor**:

- `DEEPSEEK_API_KEY`: clave privada. Nunca en el chat, Git, JavaScript público ni
  variables `NEXT_PUBLIC_`. Si ya está en Vercel, no hay que copiarla al repositorio.
- `DEEPSEEK_MODEL`: opcional; por defecto `deepseek-flash`.

La API cobra por uso. El diagnóstico consulta `/models` sin pedir una generación;
comprueba clave/modelo, pero no demuestra saldo suficiente ni una respuesta real.
La UI distingue clave ausente, clave rechazada, saldo, límite, tiempo de espera y
respuesta inválida, sin exponer el mensaje interno del proveedor ni la clave.

La autenticación de administrador y MFA de Supabase sigue siendo obligatoria para
IA y acciones de dispositivos. El editor y las ideas funcionan sin consultar la IA.
Mantén las variables Supabase existentes en Vercel. Referencias de configuración:
`OMEGA-ADMIN-LEEME.md` y SQL de `db/`.

## Voz conectada a la IA

El recorrido es: **micrófono → reconocimiento del navegador → DeepSeek → validación
local de la acción → resultado visible → lectura opcional del navegador**.

DeepSeek interpreta la transcripción, con el mismo historial e idioma que una
petición escrita. El audio no se envía a DeepSeek. El reconocimiento del navegador
puede utilizar servicios del fabricante; la síntesis usa las voces disponibles,
identificadas como locales u online. El funcionamiento depende del navegador,
permisos y sistema operativo. El teclado sigue disponible.

Una única instancia de reconocimiento se pausa durante la consulta y mientras habla
el asistente, y se reanuda al terminar si el usuario mantiene la escucha activada.
Cancelar detiene la petición pendiente y los reinicios programados. El dictado del
editor y del código comparte el micrófono, pero conserva su destino literal.

Las acciones se validan con un catálogo cerrado; nunca se ejecuta código del modelo,
se aceptan permisos, pagos o firmas automáticamente, ni se afirma que Windows terminó
una acción solo porque se envió la solicitud.

## Proyecto existente de Vercel: hologramo-gemini

En Vercel, configura `DEEPSEEK_API_KEY` en los entornos que vayas a utilizar
(Production; también Preview si quieres probar despliegues de vista previa).
Una variable añadida después de un despliegue requiere un **nuevo despliegue**.

Con la CLI autenticada y desde este repositorio:

```bash
vercel login
vercel link --project hologramo-gemini
vercel deploy --prod
```

Selecciona el equipo propietario del proyecto existente; no crees otro proyecto.
Los cambios preparados en esta máquina no aparecen automáticamente en una copia
local de Windows ni en GitHub. No despliegues otra copia sin incorporar estos archivos.
La CLI de esta sesión no está autenticada: no se ha publicado ni verificado el proyecto
remoto. La clave que añadiste en Vercel tampoco está disponible automáticamente aquí;
las pruebas del proveedor la sustituyen por una frontera simulada.

## Agente de escritorio

`scripts/ciudad-agent.mjs` admite una lista cerrada de aplicaciones Windows/macOS con
confirmación local. Requiere Node y el secreto de puente compartido con el servidor:

```powershell
node --env-file=.env.agent scripts/ciudad-agent.mjs
```

`.env.agent` (ignorado por Git): `CIUDAD_SITE_URL` como origen HTTPS del despliegue y
`OMEGA_WINDOWS_BRIDGE_SECRET` como secreto de 64 caracteres hexadecimales. No se
incluyen valores. Ctrl+C detiene el agente. Las pruebas de política y protocolo se
hacen aquí; Windows y macOS necesitan validación nativa. Una solicitud de apertura
aceptada por el sistema no verifica la ventana ni su contenido.

La web es adaptable a móvil y tableta. APK, IPA y tiendas quedan para una fase posterior.

## Privacidad y accesibilidad

Sin publicidad ni analítica añadida. Preferencias persistentes solo con permiso;
ideas guardadas por acción explícita; editor, código y chat en memoria de la pestaña.
Cerrar sesión borra conversación, editor y código de la sesión actual. El servidor
remite preguntas e historial acotado a DeepSeek; revisa su política de privacidad.

Cámara, micrófono y pantalla son opcionales. MediaPipe carga recursos desde jsDelivr
y procesa los gestos en el dispositivo. Una pinza se anuncia, sin autorizar ni ejecutar
órdenes de sistema. La pantalla compartida es una vista previa local; el modelo de
texto no la ve.

Foco visible, teclado, regiones de estado, contraste, tamaño de texto, reducción de
movimiento, idioma, voz, volumen y velocidad configurables. Las comprobaciones
automáticas no equivalen a certificación WCAG ni sustituyen pruebas con usuarios.

`/privacidad` y `/cookies` explican el tratamiento real. Deben completarse identidad
legal y contacto verificados del responsable antes de una apertura pública con datos
personales. «Ivan el notas» es una firma editorial, sin certificación electrónica.

Los archivos de Llama/Ollama se conservan como herramientas opcionales históricas;
no forman parte del flujo de IA actual ni son necesarios para desplegar la web.
