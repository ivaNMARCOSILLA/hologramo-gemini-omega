import { omegaAdminGate } from '@/lib/omega-admin-access';
import { CENTRAL_SYSTEM, parseCentralReply } from '@/lib/omega-central';
import { routeOmegaCommand } from '@/lib/omega-command-v11';
import { deepseekChat, deepseekStatus, DeepSeekError } from '@/lib/ciudad-deepseek';

export const maxDuration = 60;

const headers = { 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' };
const json = (data: object, status = 200) => Response.json(data, { status, headers });
function sameOrigin(request: Request) {
  try {
    const origin = request.headers.get('origin');
    if (!origin) return false;
    const source = new URL(origin), target = new URL(request.url);
    const development = process.env.NODE_ENV === 'development' && target.protocol === 'http:' &&
      source.protocol === 'http:' && ['localhost','127.0.0.1'].includes(target.hostname) &&
      ['localhost','127.0.0.1'].includes(source.hostname) && source.port === target.port;
    return (target.protocol === 'https:' && source.origin === target.origin || development) &&
      (!request.headers.get('sec-fetch-site') || request.headers.get('sec-fetch-site') === 'same-origin');
  } catch { return false; }
}
export async function GET(request: Request) {
  const gate = await omegaAdminGate(request, true);
  if (gate.state !== 'admin') return json({ error: gate.state }, gate.status);
  try {
    const state = await deepseekStatus();
    return json({ ...state, enabled: state.ready, message: state.ready ? 'DeepSeek disponible mediante su API.' : 'La API de DeepSeek no está disponible. Revisa el estado indicado.' });
  } catch { return json({ enabled: false, error: 'deepseek_unreachable' }, 503); }
}
export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({ error: 'origin_denied' }, 403);
  if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) return json({ error: 'invalid_type' }, 415);
  if (Number(request.headers.get('content-length')) > 20_000) return json({ error: 'too_large' }, 413);
  try {
    const gate = await omegaAdminGate(request, true);
    if (gate.state !== 'admin') return json({ error: gate.state }, gate.status);
    const raw = await request.text();
    if (raw.length > 20_000) return json({ error: 'too_large' }, 413);
    let data: { prompt?: unknown; mode?: unknown; language?: unknown; history?: unknown };
    try { data = JSON.parse(raw); } catch { return json({ error: 'invalid_json' }, 400); }
    if (!data || typeof data !== 'object' || Array.isArray(data) || typeof data.prompt !== 'string' || data.prompt.trim().length < 2 || data.prompt.length > 2500) return json({ error: 'invalid_prompt' }, 400);
    const control = data.mode === 'control';
    const local = routeOmegaCommand(data.prompt);
    if (control && local?.kind === 'restricted') return json({ answer: local.reason, instruction: null });
    const languages: Record<string, string> = { es: 'español', en: 'English', fr: 'français', pt: 'português' };
    const language = typeof data.language === 'string' ? languages[data.language] || languages.es : languages.es;
    const history: {role:'user'|'assistant';content:string}[] = [];
    if (Array.isArray(data.history)) for (const item of data.history.slice(-6)) {
      if (item && typeof item === 'object' && ['user','assistant'].includes(item.role) && typeof item.content === 'string')
        history.push({role:item.role,content:item.content.slice(0,1200)});
    }
    const result = await deepseekChat([
      { role: 'system', content: `${control ? CENTRAL_SYSTEM : 'Eres Ciudad Centralizada, asistente con DeepSeek. Responde con claridad y reconoce tus límites. Nunca afirmes ejecutar acciones sin confirmación.'}\nResponde al usuario en ${language}. Las frases canónicas de las acciones conservan su formato español.` },
      ...history, { role: 'user', content: data.prompt.trim() },
    ], { json: control, signal: request.signal });
    if (control) {
      try { return json({ ...parseCentralReply(result.text), model: result.model, provider: result.provider, tokensPerSecond: result.tokensPerSecond }); }
      catch { return json({ error: 'invalid_control_reply' }, 502); }
    }
    return json({ answer: result.text, model: result.model, provider: result.provider });
  } catch (error) {
    return json({ error: error instanceof DeepSeekError ? error.code : 'deepseek_unreachable' }, error instanceof DeepSeekError ? error.status : 503);
  }
}
