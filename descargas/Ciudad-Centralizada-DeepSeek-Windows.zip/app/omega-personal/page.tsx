import Link from 'next/link';
import OmegaV09Account from '@/components/OmegaV09Account';
export default function Personal(){return <main className="cc-legal cc-account"><Link href="/">← Ciudad Centralizada</Link><h1>Tu cuenta, tu control.</h1><OmegaV09Account/></main>;}
