import { deepseekChat, DeepSeekError } from "@/lib/ciudad-deepseek";
import { omegaAdminGate } from "@/lib/omega-admin-access";

/**
 * Ciudad Centralizada · código con DeepSeek. Solo admin verificado en servidor.
 * Mismo origen, JSON, tamaño limitado, 20 peticiones / 10 min por usuario (por instancia).
 * Devuelve texto; NUNCA ejecuta el código generado.
 */
export const maxDuration = 60;

const headers = { "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" };
const LANGS = ["typescript", "javascript", "python", "html", "css", "sql", "bash", "powershell", "json", "react"] as const;
const hits = new Map<string, number[]>();

function sameOrigin(req: Request): boolean {
  try {
    const origin = req.headers.get("origin");
    return !!origin && new URL(origin).origin === new URL(req.url).origin;
  } catch {
    return false;
  }
}

function extractCode(text: string): string {
  const m = text.match(/```[a-zA-Z0-9_+-]*\n([\s\S]*?)```/);
  return (m ? m[1] : text).trim();
}

export async function POST(request: Request): Promise<Response> {
  if (!sameOrigin(request)) return Response.json({ error: "origin_denied" }, { status: 403, headers });
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json"))
    return Response.json({ error: "json_required" }, { status: 415, headers });
  try {
    const access = await omegaAdminGate(request, true);
    if (access.state !== "admin") return Response.json({ error: access.state }, { status: access.status, headers });

    const now = Date.now();
    const recent = (hits.get(access.userId) ?? []).filter((t) => now - t < 600_000);
    if (recent.length >= 20) return Response.json({ error: "rate_limited" }, { status: 429, headers });
    recent.push(now);
    hits.set(access.userId, recent);

    const raw = await request.text();
    if (raw.length > 8000) return Response.json({ error: "too_large" }, { status: 413, headers });
    let body: unknown;
    try { body = JSON.parse(raw); } catch { return Response.json({ error: "invalid_json" }, { status: 400, headers }); }
    const { prompt, language } = (body ?? {}) as { prompt?: unknown; language?: unknown };
    if (typeof prompt !== "string" || prompt.trim().length < 3 || prompt.length > 4000)
      return Response.json({ error: "invalid_prompt" }, { status: 400, headers });
    const lang = LANGS.find((l) => l === language) ?? "typescript";

    const result = await deepseekChat([
      { role: "system", content: `Eres Ciudad Centralizada, asistente DeepSeek en modo programación. Devuelve solo un bloque de código ${lang}. No incluyas credenciales ni operaciones destructivas. Nunca ejecutes el código.` },
      { role: "user", content: prompt.trim() },
    ], { signal: request.signal, maxTokens: 1600 });
    const text = result.text;
    const model = result.model;
    return Response.json({ code: extractCode(text), language: lang, model }, { status: 200, headers });
  } catch (error) {
    return Response.json({ error: error instanceof DeepSeekError ? error.code : "code_engine_unavailable" }, { status: error instanceof DeepSeekError ? error.status : 503, headers });
  }
}