export { deepseekModel as omegaModel } from "./ciudad-deepseek";
