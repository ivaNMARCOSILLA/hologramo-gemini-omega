#!/usr/bin/env node
import { spawn } from 'node:child_process';
import { applicationTarget,validJob,agentOrigin } from './ciudad-agent-policy.mjs';
const site=agentOrigin(process.env.CIUDAD_SITE_URL||'https://hologramo.es');
const key=process.env.OMEGA_WINDOWS_BRIDGE_SECRET;
if(!/^[a-f0-9]{64}$/.test(key||''))throw new Error('Configure OMEGA_WINDOWS_BRIDGE_SECRET securely on the server and this computer. Never paste it in chat.');
if(!['win32','darwin'].includes(process.platform))throw new Error('Desktop agent supports Windows and macOS; this platform is not implemented.');
let stopping=false;let dialog=null;const pending=new AbortController();
process.on('SIGINT',()=>{stopping=true;pending.abort();dialog?.kill();});process.on('SIGTERM',()=>{stopping=true;pending.abort();dialog?.kill();});
async function api(body){
 const response=await fetch(`${site}/api/omega-windows/agent`,{method:'POST',redirect:'error',headers:{'Content-Type':'application/json','x-omega-bridge-key':key},body:JSON.stringify(body),signal:AbortSignal.any([pending.signal,AbortSignal.timeout(15000)])});
 if(!response.ok)throw new Error(`Bridge returned HTTP ${response.status}`);return response.json();
}
function run(command,args,timeout=60000){return new Promise(resolve=>{
 let settled=false;const finish=value=>{if(settled)return;settled=true;dialog=null;clearTimeout(timer);resolve(value);};
 const child=spawn(command,args,{shell:false,stdio:'ignore',windowsHide:false});dialog=child;
 const timer=setTimeout(()=>{child.kill();finish(false);},timeout);
 child.once('error',()=>finish(false));child.once('exit',code=>finish(code===0));
 });}
function consent(app){
 // app is checked against the static target map before constructing a dialog.
 if(process.platform==='win32')return run('powershell.exe',['-NoProfile','-STA','-Command',`Add-Type -AssemblyName PresentationFramework; $r=[System.Windows.MessageBox]::Show('Ciudad Centralizada solicita abrir ${app}. ¿Permitir esta acción?','Ciudad Centralizada','YesNo','Question'); if ($r -eq 'Yes') { exit 0 } else { exit 1 }`]);
 return run('/usr/bin/osascript',['-e',`display dialog "Ciudad Centralizada solicita abrir ${app}. ¿Permitir esta acción?" buttons {"Cancelar", "Permitir"} default button "Cancelar" cancel button "Cancelar" with title "Ciudad Centralizada"`]);
}
async function open(target){
 // Do not wait for a GUI app to close, and do not report that its window was verified.
 return new Promise(resolve=>{
  const child=spawn(target.command,target.args,{shell:false,detached:true,stdio:'ignore'});
  child.once('error',()=>resolve(false));child.once('spawn',()=>{child.unref();resolve(true);});
 });
}
console.log('Ciudad Centralizada: agente iniciado. Cada acción requiere confirmación local. Ctrl+C para detener.');
while(!stopping){
 try{
  const{job}=await api({action:'poll',platform:process.platform});
  if(job){
   if(!validJob(job))throw new Error('Invalid job received; no action executed.');
   const target=applicationTarget(process.platform,job.app);
   let result='failed',message='Aplicación no admitida en este sistema.';
   if(target){
    const approved=await consent(job.app);
    if(stopping)break;
    if(approved){const launched=await open(target);result=launched?'completed':'failed';message=launched?'Solicitud de apertura aceptada por el sistema; no se verifica el contenido de la ventana.':'El sistema rechazó la apertura.';}
    else{result='denied';message='Acción denegada o confirmación caducada.';}
   }
   await api({action:'finish',jobId:job.id,result,message});
  }
 }catch(error){if(!stopping)console.error(error instanceof Error?error.message:'Bridge error');}
 if(!stopping)await new Promise(resolve=>setTimeout(resolve,3000));
}
