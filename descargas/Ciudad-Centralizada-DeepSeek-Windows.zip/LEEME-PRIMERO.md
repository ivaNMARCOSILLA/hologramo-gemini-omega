# Ciudad Centralizada · DeepSeek · Windows

## En este orden

1. Extrae **todo el ZIP en una carpeta nueva**. No ejecutes los archivos dentro del ZIP.
   Si Windows bloquea los scripts descargados, abre primero Propiedades del ZIP,
   marca **Desbloquear**, aplica el cambio y vuelve a extraerlo. Los lanzadores usan
   `RemoteSigned` solo para su proceso; no cambian la politica permanente del equipo.
2. Copia tu `.env.local` desde tu proyecto anterior a la carpeta nueva, junto a
   `package.json`. No lo pegues en el chat ni lo subas a GitHub. Los instaladores
   **no crean, sobrescriben ni publican ese archivo**.
3. Abre **INSTALAR-CIUDAD.cmd**. Comprueba Node.js 24 o superior y npm; si hace falta,
   intenta instalar Node LTS con winget. Windows puede pedir permiso. Despues ejecuta
   `npm ci`, la generacion de tipos de Next.js, TypeScript, las pruebas y la compilacion. Si un paso falla, se detiene.
4. Abre **VER-WEB.cmd**. Mantiene el servidor local en esa ventana. Abre en tu navegador
   la direccion `Local` que muestre la consola. Ctrl+C detiene el servidor.
5. Para publicar, abre **PUBLICAR-VERCEL.cmd**. Inicia sesion en Vercel cuando se indique.
   Comprueba el proyecto **existente `holograma-gemini`**, revisa los nombres de sus
   variables Production, instala/valida/compila y despliega las fuentes a ese proyecto.

Si el proyecto pertenece a otro equipo, desde PowerShell en esta carpeta:

```powershell
.\PUBLICAR-VERCEL.cmd -Scope nombre-del-equipo
```

El publicador se detiene si no encuentra el proyecto, si la carpeta esta vinculada
con otro proyecto, si Root Directory no corresponde a esta carpeta raiz o si faltan
variables. No crea otro proyecto ni cambia su configuracion a ciegas. La CLI se
obtiene con npx y una version fijada; no necesita instalacion global.

## Variables necesarias

En tu `.env.local`, para probar la IA y la cuenta en el ordenador:

- `DEEPSEEK_API_KEY`: tu clave privada existente.
- `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`: la configuracion
  de tu proyecto Supabase existente. La IA mantiene administrador y MFA.
- `DEEPSEEK_MODEL`: opcional; por defecto `deepseek-flash`.

En Vercel, las tres variables obligatorias deben estar en **Settings → Environment
Variables → Production** del proyecto `holograma-gemini`. El archivo local no se sube.
El publicador reutiliza las variables remotas y no imprime sus valores.

No hacen falta Ollama, una GPU, Python ni el agente de escritorio para arrancar la web.
El agente Windows/macOS es otra funcion: no se instala ni se activa automaticamente.
El reconocimiento de voz depende del navegador y de los permisos del microfono.
DeepSeek recibe texto y contexto, y cobra por uso de su API.

## Que se ha verificado y que debes probar

El codigo de la web supero 69 pruebas, TypeScript y compilacion en el entorno de
preparacion. Se comprobo la coordinacion de voz con un reconocedor simulado y las
reglas de los instaladores/publicador en PowerShell. La instalacion nativa con winget
requiere Windows. No se ha accedido a tu cuenta de Vercel ni probado aqui tu clave real.

Tras publicar, inicia sesion, verifica MFA, escribe una pregunta y despues prueba el
microfono. El exito del despliegue o un HTTP 200 no demuestra por si solo una respuesta
real de DeepSeek ni una accion del agente. Si falla algun paso, conserva el error de
la consola; no compartas claves, tokens ni el contenido de `.env.local`.

El ZIP no contiene `.env`, `.git`, `node_modules`, `.next`, credenciales ni configuracion
privada de Vercel. Una copia de seguridad de tu proyecto anterior sigue siendo tuya:
extraer en una carpeta nueva evita sobrescribir tus archivos.
