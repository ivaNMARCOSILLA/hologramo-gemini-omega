'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import CiudadWorkspace from '@/components/CiudadWorkspace';
import { adminFetch, onAuthChange } from '@/lib/omega-admin-fetch';
import { routeOmegaCommand } from '@/lib/omega-command-v11';
import type { CentralInstruction } from '@/lib/omega-central';
import { createVoiceLoop, type CiudadVoiceLoop } from '@/lib/ciudad-voice-loop';
import { aiErrorMessage } from '@/lib/ciudad-ai-errors';
import { announce, speechLocales, translate, type Locale } from '@/lib/ciudad-i18n';

type RecognitionEvent = { results: { isFinal:boolean; 0:{transcript:string} }[]; resultIndex:number };
type Recognition = { lang:string; continuous:boolean; interimResults:boolean; start():void; stop():void; abort():void;
 onstart:(()=>void)|null; onend:(()=>void)|null; onerror:((event:{error:string})=>void)|null; onresult:((event:RecognitionEvent)=>void)|null };
type SpeechWindow = Window & { SpeechRecognition?:new()=>Recognition; webkitSpeechRecognition?:new()=>Recognition };
export type CiudadPrefs = { voice:boolean; large:boolean; contrast:boolean; motion:boolean; rate:number; voiceURI:string; volume:number };
export type ChatMessage = { role:'user'|'assistant'; content:string };
export default function Home() {
  const [locale,setLocale] = useState<Locale>('es');
  const [prefs,setPrefs] = useState<CiudadPrefs>({voice:false,large:false,contrast:false,motion:true,rate:1,voiceURI:'',volume:1});
  const [chat,setChat] = useState<ChatMessage[]>([]);
  const [busy,setBusy] = useState(false);
  const [listening,setListening] = useState(false);
  const [speaking,setSpeaking] = useState(false);
  const [micSupported,setMicSupported] = useState(true);
  const [transcript,setTranscript] = useState('');
  const [status,setStatus] = useState('');
  const controller = useRef<AbortController|null>(null);
  const recognition = useRef<Recognition|null>(null);
  const continuous = useRef(false);
  const voiceLoop=useRef<CiudadVoiceLoop|null>(null);
  const speechGeneration=useRef(0);
  const speakingNow=useRef(false);
  const dictation=useRef<'tools'|'code'|null>(null);
  const speechTimer = useRef<ReturnType<typeof setTimeout>|null>(null);
  const state = useRef({locale,prefs,chat,busy});
  useEffect(()=>{state.current={locale,prefs,chat,busy};},[locale,prefs,chat,busy]);
  const t = useCallback((key:Parameters<typeof translate>[1])=>translate(locale,key),[locale]);

  const stop = useCallback(()=>{
    controller.current?.abort();
    continuous.current=false;dictation.current=null;voiceLoop.current?.disable();voiceLoop.current?.speech(false);
    speechGeneration.current++;speakingNow.current=false;
    recognition.current?.abort();
    window.speechSynthesis?.cancel();
    if(speechTimer.current) clearTimeout(speechTimer.current);
    setSpeaking(false);setListening(false);setTranscript('');
  },[]);
  useEffect(()=>{
    const onFeedback=(event:Event)=>{
      const {message,speak=true}=(event as CustomEvent<{message:string;speak?:boolean}>).detail;
      if(!message) return;
      setStatus(message);
      if(!speak || !state.current.prefs.voice || !('speechSynthesis' in window)) return;
      const generation=++speechGeneration.current;
      speakingNow.current=true;voiceLoop.current?.speech(true);
      window.speechSynthesis.cancel();
      recognition.current?.stop();
      const utterance=new SpeechSynthesisUtterance(message);
      utterance.lang=speechLocales[state.current.locale];
      utterance.rate=state.current.prefs.rate;utterance.volume=state.current.prefs.volume;
      const voices=window.speechSynthesis.getVoices();
      utterance.voice=voices.find(v=>v.voiceURI===state.current.prefs.voiceURI)||voices.find(v=>v.lang===utterance.lang)||voices.find(v=>v.lang.startsWith(state.current.locale))||null;
      setSpeaking(true);
      const done=()=>{if(generation!==speechGeneration.current)return;speakingNow.current=false;setSpeaking(false);voiceLoop.current?.speech(false);};
      utterance.onend=done;utterance.onerror=done;
      window.speechSynthesis.speak(utterance);
    };
    const cancel=()=>stop();
    window.addEventListener('ciudad:feedback',onFeedback);
    window.addEventListener('omega:voice-cancel',cancel);
    return()=>{window.removeEventListener('ciudad:feedback',onFeedback);window.removeEventListener('omega:voice-cancel',cancel);stop();};
  },[stop]);

  const ask = useCallback(async (raw:string)=>{
    const prompt=raw.trim();if(!prompt)return;
    const language=state.current.locale;
    if(/^(?:cancelar?|cancela|stop|cancel|arrête|parar)[.!?]*$/i.test(prompt)) {stop();announce(translate(language,'cancelled'));return;}
    if(controller.current)return;
    const local=routeOmegaCommand(prompt);
    if(local?.kind==='restricted'){announce(local.reason);return;}
    const request=new AbortController();controller.current=request;
    voiceLoop.current?.processing(true);recognition.current?.stop();setBusy(true);
    setChat(old=>[...old,{role:'user' as const,content:prompt}].slice(-30));
    announce(translate(language,'thinking'),false);
    try{
      const response=await adminFetch('/api/omega-admin/ai',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({prompt,mode:'control',language,history:state.current.chat.slice(-6)}),signal:request.signal});
      if(request.signal.aborted)return;
      if(!response || [401,403].includes(response.status))throw new Error('auth');
      const data=await response.json() as {answer?:string;instruction?:CentralInstruction|null;error?:string};
      if(!response.ok || !data.answer)throw new Error(data.error||'server');
      if(request.signal.aborted)return;
      setChat(old=>[...old,{role:'assistant' as const,content:data.answer!}].slice(-30));
      if(data.instruction?.kind==='voice_stop'){stop();announce(translate(language,'cancelled'));}
      else if(data.instruction?.kind==='voice_start') {continuous.current=true;voiceLoop.current?.enable();announce(translate(language,'ready'));}
      else if(data.instruction){window.dispatchEvent(new CustomEvent('ciudad:command',{detail:data.instruction}));}
      else announce(data.answer);
    }catch(error){
      if(request.signal.aborted)return;
      const message=aiErrorMessage(error instanceof Error?error.message:'unknown',language);
      setChat(old=>[...old,{role:'assistant' as const,content:message}].slice(-30));announce(message);
    }finally{
      controller.current=null;setBusy(false);
      voiceLoop.current?.processing(false);
    }
  },[stop]);
  const askRef=useRef(ask);useEffect(()=>{askRef.current=ask;},[ask]);
  useEffect(()=>{
    const Speech=(window as SpeechWindow).SpeechRecognition||(window as SpeechWindow).webkitSpeechRecognition;
    if(!Speech){const timer=setTimeout(()=>setMicSupported(false),0);return()=>clearTimeout(timer);}
    const instance=new Speech();instance.lang=speechLocales[locale];instance.continuous=false;instance.interimResults=true;
    const loop=createVoiceLoop(()=>{try{instance.start();}catch{continuous.current=false;setListening(false);}},()=>{try{instance.stop();}catch{}},run=>{const timer=setTimeout(run,650);return()=>clearTimeout(timer);});
    voiceLoop.current=loop;
    instance.onstart=()=>{loop.started();setListening(true);};
    instance.onend=()=>{setListening(false);loop.ended();};
    instance.onerror=event=>{if(event.error!=='aborted'&&event.error!=='no-speech'){continuous.current=false;loop.disable();announce(translate(state.current.locale,'permission'));}setListening(false);};
    instance.onresult=event=>{
      if(speakingNow.current||controller.current)return;
      for(let i=event.resultIndex;i<event.results.length;i++){
        const text=event.results[i][0].transcript.trim();setTranscript(text);
        if(event.results[i].isFinal){if(dictation.current){const target=dictation.current;dictation.current=null;recognition.current?.stop();window.dispatchEvent(new CustomEvent('ciudad:dictation-result',{detail:{target,text}}));}else void askRef.current(text);setTranscript('');}
      }
    };
    recognition.current=instance;
    return()=>{continuous.current=false;instance.onstart=null;instance.onend=null;instance.onerror=null;instance.onresult=null;loop.dispose();instance.abort();recognition.current=null;voiceLoop.current=null;};
  },[locale]);
  useEffect(()=>{
    const startDictation=(event:Event)=>{
      const target=(event as CustomEvent<'tools'|'code'>).detail;
      if(!recognition.current){announce(translate(state.current.locale,'noMic'));return;}
      stop();dictation.current=target;
      speechTimer.current=setTimeout(()=>{try{recognition.current?.start();}catch{dictation.current=null;announce(translate(state.current.locale,'permission'));}},200);
    };
    window.addEventListener('ciudad:dictate',startDictation);return()=>window.removeEventListener('ciudad:dictate',startDictation);
  },[stop]);
  const toggleMic=()=>{
    if(listening||continuous.current||busy){stop();announce(t('cancelled'));return;}
    if(!recognition.current){announce(t('noMic'));return;}
    continuous.current=true;
    voiceLoop.current?.enable();
  };
  useEffect(()=>onAuthChange(event=>{if(event==='SIGNED_OUT'){stop();setChat([]);window.dispatchEvent(new Event('ciudad:signed-out'));}}),[stop]);
  useEffect(()=>{document.documentElement.lang=locale;},[locale]);
  return <CiudadWorkspace locale={locale} onLocale={setLocale} prefs={prefs} onPrefs={setPrefs}
    chat={chat} onClearChat={()=>{stop();setChat([]);announce(t('done'));}} onAsk={ask}
    busy={busy} listening={listening} speaking={speaking} micSupported={micSupported}
    transcript={transcript} status={status} onMic={toggleMic} onStop={()=>{stop();announce(t('cancelled'));}} />;
}
