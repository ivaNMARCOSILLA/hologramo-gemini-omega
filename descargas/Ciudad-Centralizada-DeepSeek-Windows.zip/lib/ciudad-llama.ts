import { availableParallelism } from 'node:os';

export type LlamaMessage = { role: 'system' | 'user' | 'assistant'; content: string };
export class LlamaError extends Error {
  constructor(public code: string, public status = 503) { super(code); }
}
export function llamaModel(): string {
  const model = process.env.LLAMA_MODEL?.trim() || 'llama3.2:3b';
  if (!/^llama[\w.:-]{1,100}$/.test(model)) throw new LlamaError('llama_model_invalid');
  return model;
}
export function llamaEndpoint(): string {
  let url: URL;
  try { url = new URL(process.env.LLAMA_SERVER_URL || 'http://127.0.0.1:11434'); }
  catch { throw new LlamaError('llama_endpoint_invalid'); }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if (url.username || url.password || url.pathname !== '/' || url.search || url.hash ||
      !(url.protocol === 'https:' || (local && url.protocol === 'http:')))
    throw new LlamaError('llama_endpoint_invalid');
  return url.origin;
}
function headers() {
  return { 'Content-Type': 'application/json',
    ...(process.env.LLAMA_SERVER_TOKEN ? { Authorization: `Bearer ${process.env.LLAMA_SERVER_TOKEN}` } : {}) };
}
let active = 0;
export async function llamaChat(messages: LlamaMessage[], options: { json?: boolean; signal?: AbortSignal; maxTokens?: number } = {}) {
  if (active >= 1) throw new LlamaError('llama_busy', 429);
  const endpoint = llamaEndpoint(), model = llamaModel();
  active++;
  try {
    const response = await fetch(`${endpoint}/api/chat`, {
      method: 'POST', redirect: 'error', headers: headers(), cache: 'no-store',
      body: JSON.stringify({ model, messages, stream: false, keep_alive: '5m',
        ...(options.json ? { format: 'json' } : {}),
        options: { num_gpu: 0, num_thread: Math.max(1, Math.min(availableParallelism(), 8)),
          num_ctx: 4096, num_predict: Math.min(options.maxTokens || 700, 1600), temperature: 0.2 } }),
      signal: AbortSignal.any([...(options.signal ? [options.signal] : []), AbortSignal.timeout(120_000)]),
    });
    if (!response.ok) throw new LlamaError(response.status === 404 ? 'llama_model_missing' : 'llama_server_error', 502);
    const body = await response.json() as { message?: { content?: unknown }; eval_count?: number; eval_duration?: number };
    if (typeof body.message?.content !== 'string' || !body.message.content.trim()) throw new LlamaError('llama_empty_reply', 502);
    return { text: body.message.content.trim(), model, provider: 'Ollama · Meta Llama',
      tokensPerSecond: body.eval_count && body.eval_duration ? Math.round(body.eval_count / body.eval_duration * 1e10) / 10 : null };
  } catch (error) {
    if (error instanceof LlamaError) throw error;
    if (options.signal?.aborted) throw new LlamaError('request_cancelled', 499);
    throw new LlamaError('llama_unreachable');
  } finally { active--; }
}
export async function llamaStatus() {
  const model = llamaModel();
  try {
    const response = await fetch(`${llamaEndpoint()}/api/tags`, { redirect: 'error', headers: headers(), cache: 'no-store', signal: AbortSignal.timeout(4000) });
    if (!response.ok) return { ready: false, model, error: 'llama_server_error' };
    const data = await response.json() as { models?: { name: string }[] };
    return { ready: data.models?.some(m => m.name === model) === true, model, provider: 'Meta Llama', compute: 'CPU',
      error: data.models?.some(m => m.name === model) ? null : 'llama_model_missing' };
  } catch { return { ready: false, model, error: 'llama_unreachable' }; }
}
