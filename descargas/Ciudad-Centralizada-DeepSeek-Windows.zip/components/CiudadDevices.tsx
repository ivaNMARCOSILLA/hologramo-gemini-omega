'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Camera, Monitor, ShieldCheck, RefreshCw, Hand } from 'lucide-react';
import { announce, translate, type Locale } from '@/lib/ciudad-i18n';
import { createBrowserClient } from '@supabase/ssr';
import { sendRemoteWindowsOrder } from '@/lib/omega-voz-dictadora';

type Bridge={connected:boolean;agentVersion?:string;requiresLocalConsent?:boolean};
export default function CiudadDevices({locale}:{locale:Locale}){
 const t=useCallback((key:Parameters<typeof translate>[1])=>translate(locale,key),[locale]);
 const [camera,setCamera]=useState(false);const [screen,setScreen]=useState(false);const [gesture,setGesture]=useState('');
 const [bridge,setBridge]=useState<Bridge|null>(null);const [bridgeBusy,setBridgeBusy]=useState(false);const [actionBusy,setActionBusy]=useState(false);
 const cameraVideo=useRef<HTMLVideoElement>(null);const screenVideo=useRef<HTMLVideoElement>(null);
 const cameraStream=useRef<MediaStream|null>(null);const screenStream=useRef<MediaStream|null>(null);
 const deviceActive=useRef(true);
 useEffect(()=>{deviceActive.current=true;return()=>{deviceActive.current=false;cameraStream.current?.getTracks().forEach(track=>track.stop());screenStream.current?.getTracks().forEach(track=>track.stop());};},[]);
 const stopCamera=useCallback(()=>{cameraStream.current?.getTracks().forEach(track=>track.stop());cameraStream.current=null;setCamera(false);setGesture('');announce(t('cameraOff'));},[t]);
 const startCamera=useCallback(async()=>{
  if(cameraStream.current)return;
  try{const stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:640},height:{ideal:480}},audio:false});
   if(!deviceActive.current){stream.getTracks().forEach(track=>track.stop());return;}
   cameraStream.current=stream;setCamera(true);announce(t('cameraOn'));
  }catch{announce(t('permission'));}
 },[t]);
 const stopScreen=useCallback(()=>{screenStream.current?.getTracks().forEach(track=>track.stop());screenStream.current=null;setScreen(false);announce(t('screenStop'));},[t]);
 const startScreen=useCallback(async()=>{
  if(screenStream.current)return;
  try{const stream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});
   if(!deviceActive.current){stream.getTracks().forEach(track=>track.stop());return;}
   screenStream.current=stream;stream.getVideoTracks()[0].onended=stopScreen;setScreen(true);announce(t('screen'));
  }catch{announce(t('permission'));}
 },[stopScreen,t]);
 useEffect(()=>{if(screen&&screenVideo.current)screenVideo.current.srcObject=screenStream.current;},[screen]);
 useEffect(()=>{
  if(!camera||!cameraVideo.current)return;
  cameraVideo.current.srcObject=cameraStream.current;
  let mounted=true;let timer:ReturnType<typeof setTimeout>;let close:(()=>void)|undefined;let lastPinch=0;let pinched=false;
  void(async()=>{
   try{
    const {Hands}=await import('@mediapipe/hands');
    if(!mounted)return;
    const hands=new Hands({locateFile:file=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${file}`});
    close=()=>{void hands.close();};
    hands.setOptions({maxNumHands:1,modelComplexity:0,minDetectionConfidence:.65,minTrackingConfidence:.65});
    hands.onResults(results=>{
     const points=results.multiHandLandmarks?.[0];if(!points){pinched=false;return;}
     const distance=Math.hypot(points[4].x-points[8].x,points[4].y-points[8].y);
     if(distance<.055&&!pinched&&Date.now()-lastPinch>2500){lastPinch=Date.now();setGesture(t('gesture'));announce(t('gesture'));}
     pinched=distance<.055;
    });
    const sample=async()=>{if(!mounted)return;try{if(cameraVideo.current&&cameraVideo.current.readyState>=2)await hands.send({image:cameraVideo.current});}catch{if(mounted)setGesture(t('failed'));}finally{if(mounted)timer=setTimeout(()=>void sample(),250);}};
    void sample();
   }catch{if(mounted)setGesture(t('failed'));}
  })();
  return()=>{mounted=false;clearTimeout(timer);close?.();};
 },[camera,t]);
 useEffect(()=>{
  const receive=(event:Event)=>{const text=(event as CustomEvent<string>).detail;
   if(text==='activa la cámara')void startCamera();else if(text==='apaga la cámara')stopCamera();
   else if(text==='comparte pantalla')announce(t('screenHelp'));else if(text==='deja de compartir pantalla')stopScreen();};
  window.addEventListener('ciudad:device',receive);return()=>window.removeEventListener('ciudad:device',receive);
 },[startCamera,stopCamera,stopScreen,t]);
 const checkBridge=async()=>{
  setBridgeBusy(true);
  try{
   const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
   if(!url||!key)throw new Error('auth');
   const client=createBrowserClient(url,key);const{data}=await client.auth.getSession();
   if(!data.session)throw new Error('auth');
   const response=await fetch('/api/omega-windows',{headers:{Authorization:`Bearer ${data.session.access_token}`},cache:'no-store'});
   if([401,403].includes(response.status))throw new Error('auth');
   if(!response.ok)throw new Error('server');const body=await response.json();setBridge(body);announce(t(body.connected?'connected':'disconnected'));
  }catch(error){setBridge(null);announce(t(error instanceof Error&&error.message==='auth'?'signIn':'failed'));}finally{setBridgeBusy(false);}
 };
 return <section className="cc-panel"><h2>{t('devicesTitle')}</h2><p>{t('devicesHelp')}</p><div className="cc-device-grid">
  <article className="cc-device-card"><Monitor size={24}/><h3>{t('bridge')}</h3><span className="cc-badge">{bridge?t(bridge.connected?'connected':'disconnected'):t('unknown')}</span><p>{t('windowsHelp')}</p><button type="button" disabled={bridgeBusy} onClick={()=>void checkBridge()}><RefreshCw size={16}/>{t('check')}</button><div className="cc-actions">{['calculadora','bloc de notas','explorador','paint'].map(app=><button type="button" key={app} disabled={!bridge?.connected||actionBusy} onClick={async()=>{setActionBusy(true);try{await sendRemoteWindowsOrder(`abre ${app}`,announce);}finally{setActionBusy(false);}}}>{app}</button>)}</div></article>
  <article className="cc-device-card"><ShieldCheck size={24}/><h3>Windows · macOS · Linux</h3><p>{t('macHelp')}</p><p>{t('futureApps')}</p></article>
  <article className="cc-device-card"><Camera size={24}/><h3>{t('camera')}</h3><p>{t('cameraHelp')}</p><button type="button" onClick={()=>camera?stopCamera():void startCamera()}>{t(camera?'cameraOff':'cameraOn')}</button>{camera&&<video ref={cameraVideo} autoPlay playsInline muted aria-label={t('camera')}/>}<p role="status"><Hand size={15}/>{gesture}</p></article>
  <article className="cc-device-card"><Monitor size={24}/><h3>{t('screen')}</h3><p>{t('screenHelp')}</p><button type="button" onClick={()=>screen?stopScreen():void startScreen()}>{t(screen?'screenStop':'screen')}</button>{screen&&<video ref={screenVideo} autoPlay playsInline muted aria-label={t('screen')}/>}</article>
 </div></section>;
}
